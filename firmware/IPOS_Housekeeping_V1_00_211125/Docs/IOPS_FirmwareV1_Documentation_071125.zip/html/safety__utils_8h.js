var safety__utils_8h =
[
    [ "AllSafetiesActive", "safety__utils_8h.html#a2717bd204c433b741cf4b8db6e935623", null ],
    [ "AnySafetyOpen", "safety__utils_8h.html#a92412cbb5adc7eb94136843b1d36c1bb", null ]
];