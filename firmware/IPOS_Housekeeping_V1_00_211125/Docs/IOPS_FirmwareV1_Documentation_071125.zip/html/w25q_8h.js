var w25q_8h =
[
    [ "W25Q_CS_Pin", "w25q_8h.html#adbe676a4c841cfbef06cfa945fcb6e52", null ],
    [ "W25Q_CS_Port", "w25q_8h.html#a9cdb249cddd466b909aabaa652b3eb51", null ],
    [ "W25Q_ChipErase", "w25q_8h.html#a00a686d495b4c8b7280ceecaef291851", null ],
    [ "W25Q_Init", "w25q_8h.html#a439c6b86a3726e49bb86ffe69c23deed", null ],
    [ "W25Q_PageProgram", "w25q_8h.html#a302a3f3ca752d3d75943974f1a95df36", null ],
    [ "W25Q_Read", "w25q_8h.html#ab9c3d50b11e8142ed89516a4ff5e67bb", null ],
    [ "W25Q_ReadID", "w25q_8h.html#aaa1d0ea3b941a75d0d988feaca87b1e7", null ],
    [ "W25Q_SectorErase4K", "w25q_8h.html#ae132501e366ebfaead22af8db87efd28", null ],
    [ "W25Q_WaitBusy", "w25q_8h.html#adad51cdfa8e7d1fc87467ff788a8f51f", null ],
    [ "hspi1", "w25q_8h.html#a9c6222bae4d0328dd843ae099623b40b", null ]
];