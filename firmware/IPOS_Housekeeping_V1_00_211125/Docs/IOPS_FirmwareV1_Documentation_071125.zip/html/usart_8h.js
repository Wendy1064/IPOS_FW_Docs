var usart_8h =
[
    [ "MX_USART2_UART_Init", "usart_8h.html#a052088fe5bb3f807a4b2502e664fd4fd", null ],
    [ "huart2", "usart_8h.html#aa9479c261d65eecedd3d9582f7f0f89c", null ]
];