var spi_8c =
[
    [ "HAL_SPI_MspDeInit", "spi_8c.html#af9af6cae4cb9386b709196d3a3ab4f78", null ],
    [ "HAL_SPI_MspInit", "spi_8c.html#a8e1dadd744299fa6f8bca0e1bcbd2c00", null ],
    [ "MX_SPI1_Init", "spi_8c.html#af81398f9775695df0b172367651ca3e6", null ],
    [ "hspi1", "spi_8c.html#a9c6222bae4d0328dd843ae099623b40b", null ]
];