var struct_gpio_map__t =
[
    [ "pin", "struct_gpio_map__t.html#a498e98bea6399b3840b5f267b7e987c1", null ],
    [ "port", "struct_gpio_map__t.html#a5bf1902cd991dc69e8d15536697d4710", null ]
];