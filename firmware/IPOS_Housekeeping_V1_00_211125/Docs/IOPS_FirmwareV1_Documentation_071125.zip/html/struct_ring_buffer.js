var struct_ring_buffer =
[
    [ "buf", "struct_ring_buffer.html#a1dfc8f49d10dd742baf53d04c3735501", null ],
    [ "head", "struct_ring_buffer.html#a87817113715c194a3cfe19678fcfa0b4", null ],
    [ "size", "struct_ring_buffer.html#a4d7b67ecc3d498a5093dea1562daa75c", null ],
    [ "tail", "struct_ring_buffer.html#a2e915532ebf337299d19621f0a90bc16", null ]
];