var annotated_dup =
[
    [ "ErrorConditionFn", "struct_error_condition_fn.html", null ],
    [ "ErrorRule_t", "struct_error_rule__t.html", "struct_error_rule__t" ],
    [ "GpioMap_t", "struct_gpio_map__t.html", "struct_gpio_map__t" ],
    [ "InputEvent_t", "struct_input_event__t.html", "struct_input_event__t" ],
    [ "LogMsg_t", "struct_log_msg__t.html", "struct_log_msg__t" ],
    [ "MAX31855_Data", "struct_m_a_x31855___data.html", "struct_m_a_x31855___data" ],
    [ "ProtoFrame", "struct_proto_frame.html", "struct_proto_frame" ],
    [ "ProtoParser", "struct_proto_parser.html", "struct_proto_parser" ],
    [ "RingBuffer", "struct_ring_buffer.html", "struct_ring_buffer" ],
    [ "StatusConfig_t", "struct_status_config__t.html", "struct_status_config__t" ],
    [ "VarFrame", "struct_var_frame.html", "struct_var_frame" ]
];