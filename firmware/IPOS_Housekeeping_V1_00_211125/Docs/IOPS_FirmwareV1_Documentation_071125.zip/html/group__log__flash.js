var group__log__flash =
[
    [ "log_flash.h", "log__flash_8h.html", null ],
    [ "LogMsg_t", "struct_log_msg__t.html", [
      [ "code", "struct_log_msg__t.html#a4179f2d03ffd9ba1251cc59264445024", null ],
      [ "flags", "struct_log_msg__t.html#a6d61b9113b3afce68a79f39064b728a3", null ],
      [ "ms", "struct_log_msg__t.html#aac4d7026d10f335a7d29596699b16352", null ],
      [ "msg", "struct_log_msg__t.html#a7c8640c42e67e8ffc55776fd1847fba3", null ],
      [ "seq", "struct_log_msg__t.html#a87117ebd77c8c63c16e9a25de7180e52", null ]
    ] ],
    [ "COMMIT_VAL", "group__log__flash.html#ga1d5f5afa4da8aae64bc415c5596fab41", null ],
    [ "LOG_BASE", "group__log__flash.html#gacdd7c55a0924d6deca8d60fa4c46af20", null ],
    [ "LOG_CAPACITY", "group__log__flash.html#ga3e6daaec7e3afbd03bd78beaab01d0b9", null ],
    [ "LOG_SECTORS", "group__log__flash.html#gaa3d18ef8bebba9252ee656ca4db2eba4", null ],
    [ "REC_SIZE", "group__log__flash.html#gaf2626f3f54ad88732c3309a5c0c01760", null ],
    [ "RECS_PER_SECTOR", "group__log__flash.html#gadb2ca259a26eb6fff68cba2fe15a38ca", null ],
    [ "SECTOR_SIZE", "group__log__flash.html#gaa35bad1e92008da628f27b2f6bb270aa", null ],
    [ "__attribute__", "group__log__flash.html#gab898071398b359603a35c202e9c65f3b", null ],
    [ "Log_Append", "group__log__flash.html#gaf7be7be3d5aa3ad8ce8eb8f080d34baa", null ],
    [ "Log_CountValid", "group__log__flash.html#ga68cbde1bd242d16f0c97aa1a6a982674", null ],
    [ "Log_EraseAll", "group__log__flash.html#ga9a06f8947190ea69e5f7f6748a957855", null ],
    [ "Log_GetSequenceNext", "group__log__flash.html#ga2d734e69f4ea869029a8bb750d24540d", null ],
    [ "Log_GetWriteIndex", "group__log__flash.html#gab44417e89973f9f0c7b2d0aaa7ba25ac", null ],
    [ "Log_Init", "group__log__flash.html#ga5f3b99e0966ad05cc569bea9b503b148", null ],
    [ "Log_ReadLastN", "group__log__flash.html#ga661cd6aecf9a843941229e9789ef8d8f", null ],
    [ "vTaskLogWriter", "group__log__flash.html#gae4a37f521a0098079c9f62bb1014569f", null ],
    [ "logQueue", "group__log__flash.html#gaa42f4a4e54ef104c44df1ce00a619e7a", null ],
    [ "LogRec", "group__log__flash.html#gaa8e473f8371172fa02b2ecf3bf4b2010", null ],
    [ "seq_next", "group__log__flash.html#ga960039267784d0b901fd31737f74220d", null ],
    [ "wr_index", "group__log__flash.html#ga2e3467bd12b4bc5a03d2ef75df455976", null ]
];