var struct_input_event__t =
[
    [ "input", "struct_input_event__t.html#a073926d55a3274440c4e923d02ff1885", null ],
    [ "msg", "struct_input_event__t.html#aaa22176645d2bfa08030e5a62039d011", null ],
    [ "newState", "struct_input_event__t.html#ae7ef175f83ec7db0d2059b4816010eea", null ],
    [ "type", "struct_input_event__t.html#a92a1a7c50a0b83c12871590d2998e10c", null ]
];