var group__usb__commands =
[
    [ "usb_commands.c", "usb__commands_8c.html", null ],
    [ "App_BuildDebug2StatusWord", "group__usb__commands.html#ga94d773ffaf8f23627d2520170ee6a8b7", null ],
    [ "trim_cmd", "group__usb__commands.html#gae8c0e3448713b30d88c2ba5a733a9e14", null ],
    [ "UsbCommand_Process", "group__usb__commands.html#ga132ae4cb7de0936784e2fb4ed9ea0f17", null ],
    [ "debugBypassThermoCheck", "group__usb__commands.html#ga336794b53dc28ddf68e6b5e440c5ad89", null ],
    [ "ForceLatchEvent", "group__usb__commands.html#gac09e3335f4f6421a2c786a45f998c2a7", null ],
    [ "laserLatchedOff", "group__usb__commands.html#ga6332c0412eb3dd6ac3758a9b356ae013", null ],
    [ "ResetLatchEvent", "group__usb__commands.html#ga62b5ee21fd989192e48209d86efb4289", null ],
    [ "verboseLogging", "group__usb__commands.html#ga13513b52ba27e18fced406e65011d1b9", null ]
];