var searchData=
[
  ['task_0',['UART Master Task',['../group__uart__master__task.html',1,'']]],
  ['task_20manager_1',['Application Startup and Task Manager',['../group__app__main.html',1,'']]]
];
