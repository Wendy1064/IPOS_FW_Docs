var searchData=
[
  ['logmsg_5ft_0',['LogMsg_t',['../struct_log_msg__t.html',1,'']]]
];
