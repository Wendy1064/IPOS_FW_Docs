var searchData=
[
  ['wr_5findex_0',['wr_index',['../group__log__flash.html#ga2e3467bd12b4bc5a03d2ef75df455976',1,'wr_index:&#160;log_flash.c'],['../group__log__flash.html#ga2e3467bd12b4bc5a03d2ef75df455976',1,'wr_index:&#160;log_flash.c']]]
];
