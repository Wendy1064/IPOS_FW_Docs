var searchData=
[
  ['job_5fsel_5fin_5fmap_0',['Job_Sel_In_Map',['../ports__hw_8c.html#ab6ad091e4fc8de6c012331633464b7ff',1,'ports_hw.c']]],
  ['job_5fsel_5fout_5fmap_1',['Job_Sel_Out_Map',['../ports__hw_8c.html#a99cf38bf7e6d22347232c25a0aeb7808',1,'ports_hw.c']]],
  ['jobselshadow_2',['jobSelShadow',['../ports__hw_8h.html#a11e157ef9a3c2f2854ed16b082712421',1,'jobSelShadow:&#160;ports_hw.c'],['../ports__hw_8c.html#a11e157ef9a3c2f2854ed16b082712421',1,'jobSelShadow:&#160;ports_hw.c']]]
];
