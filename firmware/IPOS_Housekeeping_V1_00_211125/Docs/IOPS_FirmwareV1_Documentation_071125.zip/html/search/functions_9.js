var searchData=
[
  ['job_5fsel_5fin_5fread_0',['Job_Sel_In_Read',['../ports__hw_8h.html#ac88893c1d3af07ee3d7a475d2e897900',1,'Job_Sel_In_Read(void):&#160;ports_hw.c'],['../ports__hw_8c.html#ac88893c1d3af07ee3d7a475d2e897900',1,'Job_Sel_In_Read(void):&#160;ports_hw.c']]],
  ['job_5fsel_5fout_5fwrite_1',['Job_Sel_Out_Write',['../ports__hw_8h.html#a26b7eae3aff2afa4fbebf4e0fb1d746e',1,'Job_Sel_Out_Write(uint8_t value):&#160;ports_hw.c'],['../ports__hw_8c.html#a26b7eae3aff2afa4fbebf4e0fb1d746e',1,'Job_Sel_Out_Write(uint8_t value):&#160;ports_hw.c']]]
];
