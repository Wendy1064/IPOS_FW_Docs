var searchData=
[
  ['7_20example_20output_0',['7. Example Output',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md60',1,'']]],
  ['7_20example_20usage_1',['7 Example Usage',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md97',1,'7. Example Usage'],['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md138',1,'7. Example Usage']]],
  ['7_20future_20extensions_2',['7. Future Extensions',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwara0b21cab58a542a2bf33fa5fa49a0cc6.html#autotoc_md156',1,'']]],
  ['7_20temperature_20monitoring_3',['7. Temperature Monitoring',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md25',1,'']]],
  ['7_20typical_20usage_4',['7. Typical Usage',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md118',1,'']]],
  ['7_20usb_20commands_5',['7. USB Commands',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md44',1,'']]]
];
