var searchData=
[
  ['2_20architecture_0',['2 Architecture',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md90',1,'2. Architecture'],['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md129',1,'2. Architecture']]],
  ['2_20dependencies_1',['2. Dependencies',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwara0b21cab58a542a2bf33fa5fa49a0cc6.html#autotoc_md148',1,'']]],
  ['2_20frame_20structure_2',['2. Frame Structure',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md110',1,'']]],
  ['2_20hardware_20overview_3',['2. Hardware Overview',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md34',1,'']]],
  ['2_20latch_20control_20tasks_4',['5.2 Latch Control Tasks',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md22',1,'']]],
  ['2_20responsibilities_5',['2 Responsibilities',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md13',1,'2. Responsibilities'],['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar967e0c8299e13ef5d263710cc2460100.html#autotoc_md79',1,'2. Responsibilities']]],
  ['2_20tasks_6',['2. Tasks',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md54',1,'']]]
];
