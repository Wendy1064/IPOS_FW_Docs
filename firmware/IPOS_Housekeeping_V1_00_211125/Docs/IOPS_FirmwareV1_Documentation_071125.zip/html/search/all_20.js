var searchData=
[
  ['w25q_2ec_0',['w25q.c',['../w25q_8c.html',1,'']]],
  ['w25q_2eh_1',['w25q.h',['../w25q_8h.html',1,'']]],
  ['w25q_5fchiperase_2',['W25Q_ChipErase',['../w25q_8h.html#a00a686d495b4c8b7280ceecaef291851',1,'W25Q_ChipErase(void):&#160;w25q.c'],['../w25q_8c.html#a00a686d495b4c8b7280ceecaef291851',1,'W25Q_ChipErase(void):&#160;w25q.c']]],
  ['w25q_5fcs_5fpin_3',['W25Q_CS_Pin',['../w25q_8h.html#adbe676a4c841cfbef06cfa945fcb6e52',1,'w25q.h']]],
  ['w25q_5fcs_5fport_4',['W25Q_CS_Port',['../w25q_8h.html#a9cdb249cddd466b909aabaa652b3eb51',1,'w25q.h']]],
  ['w25q_5finit_5',['W25Q_Init',['../w25q_8h.html#a439c6b86a3726e49bb86ffe69c23deed',1,'W25Q_Init(void):&#160;w25q.c'],['../w25q_8c.html#a439c6b86a3726e49bb86ffe69c23deed',1,'W25Q_Init(void):&#160;w25q.c']]],
  ['w25q_5fpageprogram_6',['W25Q_PageProgram',['../w25q_8h.html#a302a3f3ca752d3d75943974f1a95df36',1,'W25Q_PageProgram(uint32_t addr, const uint8_t *data, uint32_t len):&#160;w25q.c'],['../w25q_8c.html#a302a3f3ca752d3d75943974f1a95df36',1,'W25Q_PageProgram(uint32_t addr, const uint8_t *data, uint32_t len):&#160;w25q.c']]],
  ['w25q_5fread_7',['W25Q_Read',['../w25q_8h.html#ab9c3d50b11e8142ed89516a4ff5e67bb',1,'W25Q_Read(uint32_t addr, uint8_t *buf, uint32_t len):&#160;w25q.c'],['../w25q_8c.html#ab9c3d50b11e8142ed89516a4ff5e67bb',1,'W25Q_Read(uint32_t addr, uint8_t *buf, uint32_t len):&#160;w25q.c']]],
  ['w25q_5freadid_8',['W25Q_ReadID',['../w25q_8h.html#aaa1d0ea3b941a75d0d988feaca87b1e7',1,'W25Q_ReadID(void):&#160;w25q.c'],['../w25q_8c.html#aaa1d0ea3b941a75d0d988feaca87b1e7',1,'W25Q_ReadID(void):&#160;w25q.c']]],
  ['w25q_5fsectorerase4k_9',['W25Q_SectorErase4K',['../w25q_8h.html#ae132501e366ebfaead22af8db87efd28',1,'W25Q_SectorErase4K(uint32_t addr):&#160;w25q.c'],['../w25q_8c.html#ae132501e366ebfaead22af8db87efd28',1,'W25Q_SectorErase4K(uint32_t addr):&#160;w25q.c']]],
  ['w25q_5fwaitbusy_10',['W25Q_WaitBusy',['../w25q_8h.html#adad51cdfa8e7d1fc87467ff788a8f51f',1,'W25Q_WaitBusy(uint32_t tout_ms):&#160;w25q.c'],['../w25q_8c.html#adad51cdfa8e7d1fc87467ff788a8f51f',1,'W25Q_WaitBusy(uint32_t tout_ms):&#160;w25q.c']]],
  ['w25q_5fwren_11',['W25Q_WREN',['../w25q_8c.html#a9cd913cb2efa5b7ea3476d293968a222',1,'w25q.c']]],
  ['workflow_12',['Typical Workflow',['../safety__utils_8c.html#autotoc_md5',1,'']]],
  ['wr_5findex_13',['wr_index',['../group__log__flash.html#ga2e3467bd12b4bc5a03d2ef75df455976',1,'wr_index:&#160;log_flash.c'],['../group__log__flash.html#ga2e3467bd12b4bc5a03d2ef75df455976',1,'wr_index:&#160;log_flash.c']]]
];
