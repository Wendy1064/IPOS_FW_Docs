var searchData=
[
  ['key_20features_0',['Key Features',['../index.html#features',1,'']]],
  ['key_20functions_1',['Key Functions',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar967e0c8299e13ef5d263710cc2460100.html#autotoc_md81',1,'3. Key Functions'],['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md114',1,'4. Key Functions'],['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md95',1,'5. Key Functions']]]
];
