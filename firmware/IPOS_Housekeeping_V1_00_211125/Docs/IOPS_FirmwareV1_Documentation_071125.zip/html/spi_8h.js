var spi_8h =
[
    [ "MX_SPI1_Init", "spi_8h.html#af81398f9775695df0b172367651ca3e6", null ],
    [ "hspi1", "spi_8h.html#a9c6222bae4d0328dd843ae099623b40b", null ]
];