var searchData=
[
  ['max31855_5fdata_0',['MAX31855_Data',['../struct_m_a_x31855___data.html',1,'']]]
];
