var searchData=
[
  ['nc_5f1_5fgpio_5fport_0',['NC_1_GPIO_Port',['../main_8h.html#a417f46dbf75eada0de77b0c4d8720387',1,'main.h']]],
  ['nc_5f1_5fpin_1',['NC_1_Pin',['../main_8h.html#a1773a1b04320a795d4a6872741fbe49b',1,'main.h']]],
  ['newstate_2',['newState',['../struct_input_event__t.html#ae7ef175f83ec7db0d2059b4816010eea',1,'InputEvent_t']]],
  ['nmi_5fhandler_3',['NMI_Handler',['../stm32f4xx__it_8h.html#a6ad7a5e3ee69cb6db6a6b9111ba898bc',1,'NMI_Handler(void):&#160;stm32f4xx_it.c'],['../stm32f4xx__it_8c.html#a6ad7a5e3ee69cb6db6a6b9111ba898bc',1,'NMI_Handler(void):&#160;stm32f4xx_it.c']]],
  ['no_5f1_5fgpio_5fport_4',['NO_1_GPIO_Port',['../main_8h.html#a763fc5199dcf76e0405c47127dd27ab5',1,'main.h']]],
  ['no_5f1_5fpin_5',['NO_1_Pin',['../main_8h.html#aa5378b003d87d0d3d9ff1e94f05b39ac',1,'main.h']]],
  ['notes_6',['Notes',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md124',1,'10. Notes'],['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md142',1,'11. Notes'],['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md105',1,'15. Notes']]],
  ['num_5ferror_5frules_7',['NUM_ERROR_RULES',['../inputs_8c.html#ab840ebf6ee16945e6e4995e3cbdf5a02',1,'inputs.c']]],
  ['num_5finputs_8',['NUM_INPUTS',['../group__input__handling.html#gga17ed9738c4fcd08b8a24a1d405fac706a5db28925d975294439624dfc133c4e0f',1,'inputs.h']]]
];
