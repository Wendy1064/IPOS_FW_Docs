var searchData=
[
  ['manager_0',['Application Startup and Task Manager',['../group__app__main.html',1,'']]],
  ['master_20communication_20link_1',['Master Communication Link',['../group__master__link.html',1,'']]],
  ['master_20task_2',['UART Master Task',['../group__uart__master__task.html',1,'']]]
];
