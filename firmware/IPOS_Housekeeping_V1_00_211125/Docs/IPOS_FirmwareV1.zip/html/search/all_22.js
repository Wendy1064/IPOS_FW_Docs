var searchData=
[
  ['—_20app_5fmain_20c_0',['Application Startup and Task Manager — app_main.c',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html',1,'']]],
  ['—_20input_20c_1',['Input Handler — input.c',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html',1,'']]],
  ['—_20log_5fflash_20c_2',['Flash Log Module — log_flash.c',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html',1,'']]],
  ['—_20master_5flink_20c_3',['— master_link c',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar967e0c8299e13ef5d263710cc2460100.html',1,'Master Communication Link — master_link.c'],['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html',1,'Master Link Layer — master_link.c']]],
  ['—_20protocol_20c_4',['Communication Protocol Layer — protocol.c',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html',1,'']]],
  ['—_20usart_5fmaster_5ftask_20c_5',['UART Master Task — usart_master_task.c',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html',1,'']]],
  ['—_20usb_5fcommands_20c_6',['USB Command Interface — usb_commands.c',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwara0b21cab58a542a2bf33fa5fa49a0cc6.html',1,'']]]
];
