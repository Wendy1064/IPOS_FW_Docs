var searchData=
[
  ['startup_20and_20task_20manager_0',['Application Startup and Task Manager',['../group__app__main.html',1,'']]]
];
