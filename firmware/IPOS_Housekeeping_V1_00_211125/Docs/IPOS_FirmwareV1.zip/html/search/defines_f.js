var searchData=
[
  ['var_5fporta_0',['VAR_PORTA',['../protocol_8h.html#a6103e4a953037640e7a1827788d638b2',1,'protocol.h']]],
  ['var_5fportb_1',['VAR_PORTB',['../protocol_8h.html#a278178c1887689ffd92e6620c5ca7c29',1,'protocol.h']]],
  ['var_5fportc_2',['VAR_PORTC',['../protocol_8h.html#a67d1ba916d8df2e47ed6f37967d2d4ff',1,'protocol.h']]],
  ['var_5fstatus_5factive_3',['VAR_STATUS_ACTIVE',['../protocol_8h.html#af42c2ef6d8ea1526e4128ab656e4312d',1,'protocol.h']]],
  ['var_5fstatus_5fdebug_4',['VAR_STATUS_DEBUG',['../protocol_8h.html#a805e4f6e2b596b10f0a9428b1eb2c490',1,'protocol.h']]],
  ['var_5fstatus_5fdebug2_5',['VAR_STATUS_DEBUG2',['../protocol_8h.html#ac2bd0373d9c2a9fece547b54347d0444',1,'protocol.h']]],
  ['var_5fstatus_5fplc_6',['VAR_STATUS_PLC',['../protocol_8h.html#aea33f78444a082f28126c0103fd7c057',1,'protocol.h']]],
  ['vdd_5fvalue_7',['VDD_VALUE',['../stm32f4xx__hal__conf_8h.html#aae550dad9f96d52cfce5e539adadbbb4',1,'stm32f4xx_hal_conf.h']]],
  ['vportsvchandler_8',['vPortSVCHandler',['../_free_r_t_o_s_config_8h.html#ad43047b3ea0a146673e30637488bf754',1,'FreeRTOSConfig.h']]]
];
