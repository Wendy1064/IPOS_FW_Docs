var searchData=
[
  ['task_20—_20usart_5fmaster_5ftask_20c_0',['UART Master Task — usart_master_task.c',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html',1,'']]],
  ['task_20manager_20—_20app_5fmain_20c_1',['Application Startup and Task Manager — app_main.c',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html',1,'']]]
];
