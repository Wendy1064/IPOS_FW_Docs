var searchData=
[
  ['varframe_0',['VarFrame',['../struct_var_frame.html',1,'']]]
];
