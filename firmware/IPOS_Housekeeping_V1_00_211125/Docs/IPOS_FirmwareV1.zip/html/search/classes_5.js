var searchData=
[
  ['protoframe_0',['ProtoFrame',['../struct_proto_frame.html',1,'']]],
  ['protoparser_1',['ProtoParser',['../struct_proto_parser.html',1,'']]]
];
