var searchData=
[
  ['newstate_0',['newState',['../struct_input_event__t.html#ae7ef175f83ec7db0d2059b4816010eea',1,'InputEvent_t']]]
];
