var searchData=
[
  ['role_5fmaster_0',['ROLE_MASTER',['../protocol_8h.html#abe23dea090170d3a1fc7c109f2c272b7a47f287004d68c97c3589027d98225676',1,'protocol.h']]],
  ['role_5fslave_1',['ROLE_SLAVE',['../protocol_8h.html#abe23dea090170d3a1fc7c109f2c272b7a6cff0abbfa0fc9286a1d13b0ffd76cba',1,'protocol.h']]]
];
