var searchData=
[
  ['laser_5fdisable_0',['laser_disable',['../group__input__handling.html#ga6986056511b92d173350a0e3b7513c30',1,'laser_disable(void):&#160;inputs.c'],['../group__input__handling.html#ga6986056511b92d173350a0e3b7513c30',1,'laser_disable(void):&#160;inputs.c']]],
  ['laser_5fenable_1',['laser_enable',['../group__input__handling.html#gaffe4cde7ad5ab8edbfe83781dbc7767b',1,'laser_enable(void):&#160;inputs.c'],['../group__input__handling.html#gaffe4cde7ad5ab8edbfe83781dbc7767b',1,'laser_enable(void):&#160;inputs.c']]],
  ['log_5fappend_2',['Log_Append',['../group__log__flash.html#gaf7be7be3d5aa3ad8ce8eb8f080d34baa',1,'Log_Append(uint16_t code, uint16_t flags, const char *msg):&#160;log_flash.c'],['../group__log__flash.html#gaf7be7be3d5aa3ad8ce8eb8f080d34baa',1,'Log_Append(uint16_t code, uint16_t flags, const char *msg):&#160;log_flash.c']]],
  ['log_5fcountvalid_3',['Log_CountValid',['../group__log__flash.html#ga68cbde1bd242d16f0c97aa1a6a982674',1,'Log_CountValid(void):&#160;log_flash.c'],['../group__log__flash.html#ga68cbde1bd242d16f0c97aa1a6a982674',1,'Log_CountValid(void):&#160;log_flash.c']]],
  ['log_5feraseall_4',['Log_EraseAll',['../group__log__flash.html#ga9a06f8947190ea69e5f7f6748a957855',1,'log_flash.h']]],
  ['log_5fgetsequencenext_5',['Log_GetSequenceNext',['../group__log__flash.html#ga2d734e69f4ea869029a8bb750d24540d',1,'Log_GetSequenceNext(void):&#160;log_flash.c'],['../group__log__flash.html#ga2d734e69f4ea869029a8bb750d24540d',1,'Log_GetSequenceNext(void):&#160;log_flash.c']]],
  ['log_5fgetwriteindex_6',['Log_GetWriteIndex',['../group__log__flash.html#gab44417e89973f9f0c7b2d0aaa7ba25ac',1,'Log_GetWriteIndex(void):&#160;log_flash.c'],['../group__log__flash.html#gab44417e89973f9f0c7b2d0aaa7ba25ac',1,'Log_GetWriteIndex(void):&#160;log_flash.c']]],
  ['log_5finit_7',['Log_Init',['../group__log__flash.html#ga5f3b99e0966ad05cc569bea9b503b148',1,'Log_Init(void):&#160;log_flash.c'],['../group__log__flash.html#ga5f3b99e0966ad05cc569bea9b503b148',1,'Log_Init(void):&#160;log_flash.c']]],
  ['log_5freadlastn_8',['Log_ReadLastN',['../group__log__flash.html#ga661cd6aecf9a843941229e9789ef8d8f',1,'Log_ReadLastN(uint32_t n, LogRec *out, uint32_t max_out):&#160;log_flash.c'],['../group__log__flash.html#ga661cd6aecf9a843941229e9789ef8d8f',1,'Log_ReadLastN(uint32_t n, LogRec *out, uint32_t max_out):&#160;log_flash.c']]]
];
