var searchData=
[
  ['queues_0',['3. Message Queues',['../md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md131',1,'']]]
];
