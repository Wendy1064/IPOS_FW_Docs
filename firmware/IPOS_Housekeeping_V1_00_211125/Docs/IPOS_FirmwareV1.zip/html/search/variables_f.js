var searchData=
[
  ['rangefault_0',['rangeFault',['../struct_m_a_x31855___data.html#a9ad6e5bb1cd8ecc18e6ac97d7519a7bc',1,'MAX31855_Data']]],
  ['raw_1',['raw',['../struct_m_a_x31855___data.html#a57c8c3ae38c1a9b96124632257bb0798',1,'MAX31855_Data']]],
  ['relaychecktick_2',['relayCheckTick',['../inputs_8c.html#a4876ceb2ea50e26b76d5ad1d660339b6',1,'inputs.c']]],
  ['resetlatchevent_3',['ResetLatchEvent',['../group__app__main.html#ga62b5ee21fd989192e48209d86efb4289',1,'ResetLatchEvent:&#160;app_main.c'],['../group__usb__commands.html#ga62b5ee21fd989192e48209d86efb4289',1,'ResetLatchEvent:&#160;app_main.c']]],
  ['role_4',['role',['../struct_proto_parser.html#af6b269d2101ce28da53a1b95b58b8727',1,'ProtoParser']]]
];
