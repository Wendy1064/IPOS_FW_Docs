var topics =
[
    [ "Application Startup and Task Manager", "group__app__main.html", "group__app__main" ],
    [ "Master Communication Link", "group__master__link.html", "group__master__link" ],
    [ "Communication Protocol Layer", "group__protocol.html", "group__protocol" ],
    [ "UART Master Task", "group__uart__master__task.html", "group__uart__master__task" ],
    [ "USB Command Interface", "group__usb__commands.html", "group__usb__commands" ],
    [ "Input_handling", "group__input__handling.html", "group__input__handling" ],
    [ "Log_flash", "group__log__flash.html", "group__log__flash" ]
];