var debug__flags_8h =
[
    [ "UsbCommand_Process", "group__usb__commands.html#ga132ae4cb7de0936784e2fb4ed9ea0f17", null ],
    [ "verboseLogging", "group__app__main.html#ga13513b52ba27e18fced406e65011d1b9", null ]
];