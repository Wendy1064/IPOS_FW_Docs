var error__codes_8h =
[
    [ "LOGCODE_DOOR_CLEAR", "error__codes_8h.html#a28179d49fdc6c980d58cbd7cd83a8daf", null ],
    [ "LOGCODE_DOOR_FAULT", "error__codes_8h.html#aae1e05325552454ff5d1b6f6856c6cdf", null ],
    [ "LOGCODE_LATCH_CLEAR", "error__codes_8h.html#a8ea4464921ccd05bdbfad58889386636", null ],
    [ "LOGCODE_LATCH_FAULT", "error__codes_8h.html#a234e7d69449f68d606c2b3c2f6864032", null ],
    [ "LOGCODE_OVERTEMP", "error__codes_8h.html#ae96cd3ef177943967e88f135b5385f52", null ],
    [ "LOGCODE_POWER_CLEAR", "error__codes_8h.html#ae7837b9b04a3e3bc6309c1a7d12fb0fc", null ],
    [ "LOGCODE_POWER_FAULT", "error__codes_8h.html#aa06dc77e13fa4a40d74471426eb3910e", null ],
    [ "LOGCODE_RELAY_CLEAR", "error__codes_8h.html#af62210e15c6dd6133e978685999dc0ba", null ],
    [ "LOGCODE_RELAY_FAULT", "error__codes_8h.html#ac4eeec1459b5be1ed6b1e9b855c06a6b", null ],
    [ "LOGCODE_TEMP_CLEAR", "error__codes_8h.html#a042a54b87d9ed254de6784f4e4955fbb", null ]
];