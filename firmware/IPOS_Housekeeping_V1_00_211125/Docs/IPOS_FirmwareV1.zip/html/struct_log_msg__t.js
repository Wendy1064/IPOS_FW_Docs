var struct_log_msg__t =
[
    [ "code", "struct_log_msg__t.html#a4179f2d03ffd9ba1251cc59264445024", null ],
    [ "flags", "struct_log_msg__t.html#a6d61b9113b3afce68a79f39064b728a3", null ],
    [ "ms", "struct_log_msg__t.html#aac4d7026d10f335a7d29596699b16352", null ],
    [ "msg", "struct_log_msg__t.html#a7c8640c42e67e8ffc55776fd1847fba3", null ],
    [ "seq", "struct_log_msg__t.html#a87117ebd77c8c63c16e9a25de7180e52", null ]
];