var max31855_8c =
[
    [ "bitbang_delay", "max31855_8c.html#a6a8b26ef54742fbdea812f0c83653cbf", null ],
    [ "MAX31855_Init", "max31855_8c.html#a871b334e75921c050bad079ba2589f39", null ],
    [ "MAX31855_Read", "max31855_8c.html#a30479412736dfb509d5dce8dff1aa3fa", null ],
    [ "MAX31855_ReadRaw", "max31855_8c.html#a9ab988e4c18e463e900131ce1dcca42c", null ],
    [ "MAX31855_UpdateTask", "max31855_8c.html#a54987d83e00a39041fb32fa1d2aad560", null ],
    [ "g_ThermoData", "max31855_8c.html#a336ed8079cec975211d2ca7b0b892297", null ],
    [ "g_ThermoMutex", "max31855_8c.html#a31af3eca36f369fb3233495998793e75", null ],
    [ "verboseLogging", "group__app__main.html#ga13513b52ba27e18fced406e65011d1b9", null ]
];