var max31855_8h =
[
    [ "MAX31855_Data", "struct_m_a_x31855___data.html", "struct_m_a_x31855___data" ],
    [ "MAX31855_CS_GPIO_Port", "max31855_8h.html#a9b5df1c02263f7a033e744d7b4e856e2", null ],
    [ "MAX31855_CS_Pin", "max31855_8h.html#a3e4c29bdadc8ef7e52e10f55fb928e9e", null ],
    [ "MAX31855_MISO_GPIO_Port", "max31855_8h.html#a21bc82e012b1c127dd1c49016dc71cb0", null ],
    [ "MAX31855_MISO_Pin", "max31855_8h.html#a81437539d1092397b916cdaeeaa725f5", null ],
    [ "MAX31855_SAMPLE_PERIOD_MS", "max31855_8h.html#a2103459f42cf87b5ffe27990f13ea6a1", null ],
    [ "MAX31855_SCK_GPIO_Port", "max31855_8h.html#abc4018e5b40fae15c6fd94de27e18eb9", null ],
    [ "MAX31855_SCK_Pin", "max31855_8h.html#a0cd979f8d4d94fbad8c8ff8e74538ba0", null ],
    [ "MAX31855_TEMP_MAX_C", "max31855_8h.html#ab7a117b2862e6c8cb7b954fe81a0cd88", null ],
    [ "MAX31855_TEMP_MIN_C", "max31855_8h.html#a324b886f4cc4c4cc1e6254a83ab8c7bf", null ],
    [ "MAX31855_Init", "max31855_8h.html#a871b334e75921c050bad079ba2589f39", null ],
    [ "MAX31855_Read", "max31855_8h.html#a30479412736dfb509d5dce8dff1aa3fa", null ],
    [ "MAX31855_UpdateTask", "max31855_8h.html#a54987d83e00a39041fb32fa1d2aad560", null ],
    [ "g_ThermoData", "max31855_8h.html#a336ed8079cec975211d2ca7b0b892297", null ],
    [ "g_ThermoMutex", "max31855_8h.html#a31af3eca36f369fb3233495998793e75", null ]
];