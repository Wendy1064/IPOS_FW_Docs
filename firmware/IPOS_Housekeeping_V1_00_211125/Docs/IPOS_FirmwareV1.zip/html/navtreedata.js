/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "IPOS Firmware", "index.html", [
    [ "IPOS Firmware Documentation", "index.html", "index" ],
    [ "Application Startup and Task Manager — app_main.c", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html", [
      [ "Overview", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md11", null ],
      [ "Responsibilities", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md13", null ],
      [ "Task Creation Summary", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md15", null ],
      [ "Dependencies", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md17", null ],
      [ "Initialization Sequence", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md19", null ],
      [ "Example Output", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md20", null ],
      [ "5.1 Heartbeat LED", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md21", null ],
      [ "5.2 Latch Control Tasks", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md22", null ],
      [ "5.3 Input Interrupts", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md23", null ],
      [ "PLC Communication Logic", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md24", null ],
      [ "Temperature Monitoring", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md25", null ],
      [ "Flash Self-Test", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md26", null ],
      [ "Utility Functions", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md27", null ],
      [ "Task Scheduling Summary", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md28", null ],
      [ "Related Modules", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md29", [
        [ "File: app_main.c", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarb1f87bfd618872c363a52710b8d77a56.html#autotoc_md30", null ]
      ] ]
    ] ],
    [ "Flash Log Module — log_flash.c", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html", [
      [ "Purpose", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md32", null ],
      [ "Hardware Overview", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md34", null ],
      [ "Flash Layout and Configuration", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md36", null ],
      [ "Record Format", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md38", null ],
      [ "Behaviour", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md40", null ],
      [ "FreeRTOS Integration", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md42", [
        [ "Posting a Log Message", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md43", null ]
      ] ],
      [ "USB Commands", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md44", null ],
      [ "Example Output", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md45", [
        [ "LOG DUMP", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md46", null ]
      ] ],
      [ "Error and Safety Handling", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md47", null ],
      [ "Capacity and Performance", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md48", null ],
      [ "Maintenance Commands", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md49", null ],
      [ "Revision History", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar91db77c7dae4dc199ed3adb8c4872551.html#autotoc_md50", null ]
    ] ],
    [ "Input Handler — input.c", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html", [
      [ "Overview", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md52", null ],
      [ "Tasks", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md54", null ],
      [ "Data Flow", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md56", null ],
      [ "Core Conditions Checked", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md57", null ],
      [ "Example: Posting a Log Message", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md58", null ],
      [ "USB Commands", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md59", null ],
      [ "Example Output", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md60", [
        [ "LOG DUMP:", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md61", null ]
      ] ],
      [ "Laser and Latch Control", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md62", null ],
      [ "TruPulse Status Printout", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md63", null ],
      [ "Safety Behavior Summary", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md64", null ],
      [ "Dependencies", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar8b0c072d416da3a0f45da09b73f53bf2.html#autotoc_md65", null ]
    ] ],
    [ "Master Communication Link — master_link.c", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar967e0c8299e13ef5d263710cc2460100.html", [
      [ "Overview", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar967e0c8299e13ef5d263710cc2460100.html#autotoc_md77", null ],
      [ "Responsibilities", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar967e0c8299e13ef5d263710cc2460100.html#autotoc_md79", null ],
      [ "Key Functions", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar967e0c8299e13ef5d263710cc2460100.html#autotoc_md81", null ],
      [ "Data Flow Diagram", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar967e0c8299e13ef5d263710cc2460100.html#autotoc_md83", null ],
      [ "Dependencies", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar967e0c8299e13ef5d263710cc2460100.html#autotoc_md84", null ],
      [ "Error Handling", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar967e0c8299e13ef5d263710cc2460100.html#autotoc_md85", null ],
      [ "Related Modules", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar967e0c8299e13ef5d263710cc2460100.html#autotoc_md86", null ]
    ] ],
    [ "Master Link Layer — master_link.c", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html", [
      [ "Overview", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md88", null ],
      [ "Architecture", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md90", null ],
      [ "Responsibilities", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md92", null ],
      [ "Data Flow", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md94", null ],
      [ "Key Functions", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md95", null ],
      [ "UART Callbacks", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md96", null ],
      [ "Example Usage", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md97", null ],
      [ "Internal Components", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md98", null ],
      [ "Frame Processing Logic", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md99", [
        [ "Symbol Default Description", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md100", null ]
      ] ],
      [ "Thread Synchronization", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md101", null ],
      [ "Error Recovery", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md102", null ],
      [ "Dependencies", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md103", null ],
      [ "Typical Timing", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md104", null ],
      [ "Notes", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md105", null ],
      [ "Related Modules", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwarae244a1baec6e3904cb151ae220f0efe.html#autotoc_md106", null ]
    ] ],
    [ "Communication Protocol Layer — protocol.c", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html", [
      [ "Overview", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md108", null ],
      [ "Frame Structure", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md110", [
        [ "Command Summary", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md111", null ]
      ] ],
      [ "Parser Operation", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md113", null ],
      [ "Key Functions", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md114", null ],
      [ "Example Frames", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md115", null ],
      [ "USB Print Helper", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md116", [
        [ "Feature Description", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md117", null ]
      ] ],
      [ "Typical Usage", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md118", [
        [ "On Master", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md119", null ],
        [ "On Slave", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md120", null ]
      ] ],
      [ "Dependencies", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md121", [
        [ "Module Purpose", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md122", null ]
      ] ],
      [ "Error Handling", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md123", null ],
      [ "Notes", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md124", null ],
      [ "Related Modules", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar3cab511709a80d2c7c8aa00c04896a89.html#autotoc_md125", null ]
    ] ],
    [ "UART Master Task — usart_master_task.c", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html", [
      [ "Overview", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md127", null ],
      [ "Architecture", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md129", null ],
      [ "Message Queues", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md131", null ],
      [ "Thread Function", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md133", [
        [ "Core loop:", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md134", null ]
      ] ],
      [ "Callback Functions", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md135", null ],
      [ "Task Initialization", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md136", [
        [ "Thread Attributes:", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md137", null ]
      ] ],
      [ "Example Usage", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md138", null ],
      [ "Timing and Synchronization", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md139", null ],
      [ "Dependencies", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md140", null ],
      [ "Error Handling", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md141", null ],
      [ "Notes", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md142", null ],
      [ "Related Modules", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwar20089f45f0a38f81826419b96d0ccc74.html#autotoc_md143", null ]
    ] ],
    [ "USB Command Interface — usb_commands.c", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwara0b21cab58a542a2bf33fa5fa49a0cc6.html", [
      [ "Overview", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwara0b21cab58a542a2bf33fa5fa49a0cc6.html#autotoc_md146", null ],
      [ "Dependencies", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwara0b21cab58a542a2bf33fa5fa49a0cc6.html#autotoc_md148", null ],
      [ "Command Summary", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwara0b21cab58a542a2bf33fa5fa49a0cc6.html#autotoc_md150", null ],
      [ "Implementation Details", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwara0b21cab58a542a2bf33fa5fa49a0cc6.html#autotoc_md152", null ],
      [ "Helper Function", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwara0b21cab58a542a2bf33fa5fa49a0cc6.html#autotoc_md153", null ],
      [ "Example Session", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwara0b21cab58a542a2bf33fa5fa49a0cc6.html#autotoc_md154", [
        [ "FLASH STATUS", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwara0b21cab58a542a2bf33fa5fa49a0cc6.html#autotoc_md155", null ]
      ] ],
      [ "Future Extensions", "md__d_1_2_dropbox_2dovecote_01tech_01files_2_i_p_o_s_07_coyote_08_2housekeeping_01board_2firmwara0b21cab58a542a2bf33fa5fa49a0cc6.html#autotoc_md156", null ]
    ] ],
    [ "Topics", "topics.html", "topics" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_free_r_t_o_s_config_8h.html",
"group__input__handling.html#gga17ed9738c4fcd08b8a24a1d405fac706ae3beee2ee57b6fb642230810be9b31d9",
"main_8h.html#aaca23d6a3c0bcfbbd0d95db108de4c11",
"ring__buffer_8h.html#adf151a5787897f20f667a24942d5b984",
"usart_8h_source.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';