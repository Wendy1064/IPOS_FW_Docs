var uart__master__task_8h =
[
    [ "VarFrame", "struct_var_frame.html", "struct_var_frame" ],
    [ "UartMaster_StartTasks", "group__uart__master__task.html#gae0c58a28693c31347c2942dc51f60aee", null ],
    [ "gAckQueue", "group__uart__master__task.html#gab434b0238221e0189e48d13665cfc621", null ],
    [ "gDataQueue", "group__uart__master__task.html#ga0bdb2bd938c5bcddab9b37256a1da565", null ]
];