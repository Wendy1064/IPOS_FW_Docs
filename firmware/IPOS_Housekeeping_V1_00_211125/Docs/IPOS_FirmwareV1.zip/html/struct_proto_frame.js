var struct_proto_frame =
[
    [ "cmd", "struct_proto_frame.html#ae1f39018032edf224f1267fd067b99b7", null ],
    [ "has_value", "struct_proto_frame.html#ac6f54683d49c7c38592f438bb0d26942", null ],
    [ "value", "struct_proto_frame.html#a6e3775f6efa90ef06f8902bff3aad080", null ],
    [ "var_id", "struct_proto_frame.html#a653fb48b3f23d5a7c7350998af2bf20f", null ]
];