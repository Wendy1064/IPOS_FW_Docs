var struct_proto_parser =
[
    [ "buf", "struct_proto_parser.html#a7e19c06d5c360f3f421cfc0474780768", null ],
    [ "expected", "struct_proto_parser.html#a29e2324e446bb445f20a92d77c55a576", null ],
    [ "idx", "struct_proto_parser.html#a37ec8ad3da4b016fb4b9bf04d6231734", null ],
    [ "role", "struct_proto_parser.html#af6b269d2101ce28da53a1b95b58b8727", null ]
];