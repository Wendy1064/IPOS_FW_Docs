var struct_error_rule__t =
[
    [ "active", "struct_error_rule__t.html#a44df3b91ab32ebdd1d05683fa21014f2", null ],
    [ "condition", "struct_error_rule__t.html#a515f4859b836a577b00f57e41031722e", null ],
    [ "msgActive", "struct_error_rule__t.html#a3c78ceddd33423e295a52862c71a0f99", null ],
    [ "msgCleared", "struct_error_rule__t.html#aeaaac4fe64aa26ec2a281ef1f619219f", null ]
];