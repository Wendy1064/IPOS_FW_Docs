var index =
[
    [ "Overview", "index.html#intro", null ],
    [ "System Communication Overview", "index.html#system", null ],
    [ "System Architecture", "index.html#arch", null ],
    [ "Key Features", "index.html#features", null ],
    [ "Module Overview", "index.html#modules", null ],
    [ "Build and Configuration", "index.html#build", null ],
    [ "Firmware Task Summary", "index.html#tasks", null ],
    [ "RTOS Entities", "index.html#rtos", null ],
    [ "Communication Timing", "index.html#timing", null ],
    [ "Related Modules", "index.html#links", null ],
    [ "Credits", "index.html#credits", null ]
];