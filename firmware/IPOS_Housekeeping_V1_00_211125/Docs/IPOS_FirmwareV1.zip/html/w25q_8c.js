var w25q_8c =
[
    [ "CMD_CE", "w25q_8c.html#a90f680398020583fafb3d1a9c03a2aeb", null ],
    [ "CMD_PP", "w25q_8c.html#a2543fca56aeb170a41cc9f4d9b24c4cf", null ],
    [ "CMD_RDID", "w25q_8c.html#a7dcce537746ff1c0c717f6ac1f4af57b", null ],
    [ "CMD_RDSR1", "w25q_8c.html#aa0d84257d12c7e842175d0f53c3cff45", null ],
    [ "CMD_READ", "w25q_8c.html#a9c953a6c538020e644127ee080608021", null ],
    [ "CMD_SE4K", "w25q_8c.html#ae8a34ce192630c1455e9e0b5e01df068", null ],
    [ "CMD_WREN", "w25q_8c.html#a233ab2b77759d1d35814743f08c96347", null ],
    [ "CS_H", "w25q_8c.html#add1239906ae954165f9a03da1005974e", null ],
    [ "CS_L", "w25q_8c.html#a8502fe50a46bd9c239f7ab4352bb421c", null ],
    [ "Flash_Lock", "w25q_8c.html#a603b096d78169c89bee4f09564df216d", null ],
    [ "Flash_Unlock", "w25q_8c.html#aabe2fb39b617223d5ea86d23dd44a805", null ],
    [ "W25Q_ChipErase", "w25q_8c.html#a00a686d495b4c8b7280ceecaef291851", null ],
    [ "W25Q_Init", "w25q_8c.html#a439c6b86a3726e49bb86ffe69c23deed", null ],
    [ "W25Q_PageProgram", "w25q_8c.html#a302a3f3ca752d3d75943974f1a95df36", null ],
    [ "W25Q_Read", "w25q_8c.html#ab9c3d50b11e8142ed89516a4ff5e67bb", null ],
    [ "W25Q_ReadID", "w25q_8c.html#aaa1d0ea3b941a75d0d988feaca87b1e7", null ],
    [ "W25Q_SectorErase4K", "w25q_8c.html#ae132501e366ebfaead22af8db87efd28", null ],
    [ "W25Q_WaitBusy", "w25q_8c.html#adad51cdfa8e7d1fc87467ff788a8f51f", null ],
    [ "W25Q_WREN", "w25q_8c.html#a9cd913cb2efa5b7ea3476d293968a222", null ],
    [ "flashMutex", "w25q_8c.html#a2402b1174ec026e349ebb88b3d2bc1f2", null ]
];