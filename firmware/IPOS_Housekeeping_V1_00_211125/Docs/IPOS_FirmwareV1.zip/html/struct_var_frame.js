var struct_var_frame =
[
    [ "value", "struct_var_frame.html#ac652175241bf952118facd0fc2c4ebb9", null ],
    [ "var_id", "struct_var_frame.html#a9a968c2bdb78e02febb9db37c27b7b36", null ]
];