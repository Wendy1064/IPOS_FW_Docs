var i2c_8h =
[
    [ "MX_I2C1_Init", "i2c_8h.html#ada6e763cfa4108a8d24cd27b75f2f489", null ],
    [ "hi2c1", "i2c_8h.html#af7b2c26e44dadaaa798a5c3d82914ba7", null ]
];