var i2c_8c =
[
    [ "HAL_I2C_MspDeInit", "i2c_8c.html#adaa17249f3d5001ad363c736df31c593", null ],
    [ "HAL_I2C_MspInit", "i2c_8c.html#a08b1eb7b7be5b94395127e2a33b1b67e", null ],
    [ "MX_I2C1_Init", "i2c_8c.html#ada6e763cfa4108a8d24cd27b75f2f489", null ],
    [ "hi2c1", "i2c_8c.html#af7b2c26e44dadaaa798a5c3d82914ba7", null ]
];