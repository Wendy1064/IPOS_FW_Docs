var group__app__main =
[
    [ "App_Start", "group__app__main.html#ga783607bdd6febf2b64a3f7871e1e9e4c", null ],
    [ "Flash_SelfTest", "group__app__main.html#ga067e341abc6c6153474df6a42d5919ed", null ],
    [ "HAL_GPIO_EXTI_Callback", "group__app__main.html#ga0cd91fd3a9608559c2a87a8ba6cba55f", null ],
    [ "StartEthernetTask", "group__app__main.html#gafb61de40a620d1b98523ac1673907935", null ],
    [ "to_binary_str_grouped", "group__app__main.html#ga71115d79568ca6bf736cfde16bf90e50", null ],
    [ "vTaskMonitor", "group__app__main.html#ga2e3052c8b693b6705ede47fdfbf6b8fb", null ],
    [ "BootEvent", "group__app__main.html#gad161edf016c8165e59d5fa88aeb008aa", null ],
    [ "build_date", "group__app__main.html#gaa34fa035dd3b887a67e9b0e34852f0eb", null ],
    [ "build_time", "group__app__main.html#ga766eb4a0acd5a2b6c58dac458bd7da9b", null ],
    [ "debounceTimer", "group__app__main.html#gac897f859d8c267e7f99bdddf7777d1c6", null ],
    [ "debugBypassThermoCheck", "group__app__main.html#ga5d74e16bd7fa55cbd077526304114799", null ],
    [ "ForceLatchEvent", "group__app__main.html#gac09e3335f4f6421a2c786a45f998c2a7", null ],
    [ "laserLatchedOff", "group__app__main.html#ga6332c0412eb3dd6ac3758a9b356ae013", null ],
    [ "lastPressTick", "group__app__main.html#gaa709301a600e146c64d1704742ef6941", null ],
    [ "ResetLatchEvent", "group__app__main.html#ga62b5ee21fd989192e48209d86efb4289", null ],
    [ "swLatchFaultActive", "group__app__main.html#ga8b113a17282bd33cf6e1ab2d885c5da6", null ],
    [ "swLatchForceError", "group__app__main.html#ga99ad38e5fdbdf57fbaea98f73361969f", null ],
    [ "verboseLogging", "group__app__main.html#ga13513b52ba27e18fced406e65011d1b9", null ]
];