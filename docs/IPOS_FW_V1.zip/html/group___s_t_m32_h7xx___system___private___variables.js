var group___s_t_m32_h7xx___system___private___variables =
[
    [ "D1CorePrescTable", "group___s_t_m32_h7xx___system___private___variables.html#gac0142b24f5548d68accaf0d9b795c9e1", null ],
    [ "SystemCoreClock", "group___s_t_m32_h7xx___system___private___variables.html#gaa3cd3e43291e81e795d642b79b6088e6", null ],
    [ "SystemD2Clock", "group___s_t_m32_h7xx___system___private___variables.html#gaa3016e42a01e5655e438fcf76e4ba5b0", null ]
];