var abcc__hardware__abstraction_8c_struct_i2_c___inputs_tag =
[
    [ "bJP11", "abcc__hardware__abstraction_8c.html#ad484d7503124e9ae4589b9f7e907e71f", null ],
    [ "bMD", "abcc__hardware__abstraction_8c.html#a930084962219c7f5cffa9867504fda6e", null ],
    [ "bMI", "abcc__hardware__abstraction_8c.html#acdfa731b45326daff459a2896455a343", null ],
    [ "bS2", "abcc__hardware__abstraction_8c.html#a2517943d585ed6b7af769f031342bc40", null ],
    [ "bS3", "abcc__hardware__abstraction_8c.html#ad69aeaf9b8d8f7092e14b52c6f7b9c3e", null ],
    [ "bS4", "abcc__hardware__abstraction_8c.html#a154e66f9010eded8c8c0b0ff8770b068", null ],
    [ "bS5", "abcc__hardware__abstraction_8c.html#a460e599b30adc3b1626dab365c3d35cd", null ]
];