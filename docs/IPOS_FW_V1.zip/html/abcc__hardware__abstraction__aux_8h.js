var abcc__hardware__abstraction__aux_8h =
[
    [ "ABCC_HAL_GetRestartButton", "abcc__hardware__abstraction__aux_8h.html#a1c62e928109ac6c2de9ee7bb434b3eee", null ],
    [ "ABCC_HAL_Refresh_I2C_In", "abcc__hardware__abstraction__aux_8h.html#a49345e0241d592b66179a17accca1f3d", null ],
    [ "ABCC_HAL_Refresh_I2C_Out", "abcc__hardware__abstraction__aux_8h.html#a89883afc59c6eca5a1d3c7a97ddaca2d", null ],
    [ "ABCC_HAL_Set_I2C_Handle", "abcc__hardware__abstraction__aux_8h.html#a0422eb6f43f1f1ab95504f3eabc547db", null ]
];