var searchData=
[
  ['navigation_20summary_0',['Navigation Summary',['../index.html#autotoc_md3',1,'']]],
  ['notes_1',['Notes',['../stm32_protocol.html#autotoc_md144',1,'10. Notes'],['../stm32_usart_master_task.html#autotoc_md163',1,'11. Notes']]]
];
