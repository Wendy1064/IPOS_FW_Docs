var searchData=
[
  ['jobselshadow_0',['jobSelShadow',['../ports__hw_8h.html#a11e157ef9a3c2f2854ed16b082712421',1,'jobSelShadow:&#160;ports_hw.c'],['../ports__hw_8c.html#a11e157ef9a3c2f2854ed16b082712421',1,'jobSelShadow:&#160;ports_hw.c']]]
];
