var searchData=
[
  ['max31855_5fdata_0',['MAX31855_Data',['../max31855_8h.html#struct_m_a_x31855___data',1,'']]]
];
