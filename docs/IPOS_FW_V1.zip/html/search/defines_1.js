var searchData=
[
  ['b1_5fgpio_5fport_0',['B1_GPIO_Port',['../_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2main_8h.html#a4926b92dcb220e465850d9616c27e171',1,'main.h']]],
  ['b1_5fpin_1',['B1_Pin',['../_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2main_8h.html#a31ac298fbbc8a1d6de1dc4577a108232',1,'main.h']]]
];
