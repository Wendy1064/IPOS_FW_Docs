var searchData=
[
  ['role_5fmaster_0',['ROLE_MASTER',['../_i_p_o_s__071125_2_core_2_inc_2protocol_8h.html#abe23dea090170d3a1fc7c109f2c272b7a47f287004d68c97c3589027d98225676',1,'ROLE_MASTER:&#160;protocol.h'],['../_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h.html#abe23dea090170d3a1fc7c109f2c272b7a47f287004d68c97c3589027d98225676',1,'ROLE_MASTER:&#160;protocol.h']]],
  ['role_5fslave_1',['ROLE_SLAVE',['../_i_p_o_s__071125_2_core_2_inc_2protocol_8h.html#abe23dea090170d3a1fc7c109f2c272b7a6cff0abbfa0fc9286a1d13b0ffd76cba',1,'ROLE_SLAVE:&#160;protocol.h'],['../_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h.html#abe23dea090170d3a1fc7c109f2c272b7a6cff0abbfa0fc9286a1d13b0ffd76cba',1,'ROLE_SLAVE:&#160;protocol.h']]]
];
