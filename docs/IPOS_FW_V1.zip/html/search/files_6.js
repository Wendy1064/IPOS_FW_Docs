var searchData=
[
  ['housekeeping_5foverview_2emd_0',['housekeeping_overview.md',['../housekeeping__overview_8md.html',1,'']]]
];
