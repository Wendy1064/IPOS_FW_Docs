var searchData=
[
  ['navigation_20summary_0',['Navigation Summary',['../index.html#autotoc_md3',1,'']]],
  ['nc_5f1_5fgpio_5fport_1',['NC_1_GPIO_Port',['../_i_p_o_s__071125_2_core_2_inc_2main_8h.html#a417f46dbf75eada0de77b0c4d8720387',1,'main.h']]],
  ['nc_5f1_5fpin_2',['NC_1_Pin',['../_i_p_o_s__071125_2_core_2_inc_2main_8h.html#a1773a1b04320a795d4a6872741fbe49b',1,'main.h']]],
  ['newspi2received_3',['newSPI2received',['../abcc__hardware__abstraction_8c.html#a935cf6a78beb7df83d477c66dae92e54',1,'abcc_hardware_abstraction.c']]],
  ['newstate_4',['newState',['../group__input__handling.html#ae7ef175f83ec7db0d2059b4816010eea',1,'InputEvent_t']]],
  ['nmi_5fhandler_5',['NMI_Handler',['../stm32f4xx__it_8h.html#a6ad7a5e3ee69cb6db6a6b9111ba898bc',1,'NMI_Handler(void):&#160;stm32f4xx_it.c'],['../stm32f4xx__it_8c.html#a6ad7a5e3ee69cb6db6a6b9111ba898bc',1,'NMI_Handler(void):&#160;stm32f4xx_it.c'],['../stm32h7xx__it_8h.html#a6ad7a5e3ee69cb6db6a6b9111ba898bc',1,'NMI_Handler(void):&#160;stm32f4xx_it.c'],['../stm32h7xx__it_8c.html#a6ad7a5e3ee69cb6db6a6b9111ba898bc',1,'NMI_Handler(void):&#160;stm32h7xx_it.c']]],
  ['no_5f1_5fgpio_5fport_6',['NO_1_GPIO_Port',['../_i_p_o_s__071125_2_core_2_inc_2main_8h.html#a763fc5199dcf76e0405c47127dd27ab5',1,'main.h']]],
  ['no_5f1_5fpin_7',['NO_1_Pin',['../_i_p_o_s__071125_2_core_2_inc_2main_8h.html#aa5378b003d87d0d3d9ff1e94f05b39ac',1,'main.h']]],
  ['notes_8',['Notes',['../stm32_protocol.html#autotoc_md144',1,'10. Notes'],['../stm32_usart_master_task.html#autotoc_md163',1,'11. Notes']]],
  ['null_9',['NULL',['../abcc__types_8h.html#a070d2ce7b6bb7e5c05602aa8c308d0c4',1,'abcc_types.h']]],
  ['num_5ferror_5frules_10',['NUM_ERROR_RULES',['../inputs_8c.html#ab840ebf6ee16945e6e4995e3cbdf5a02',1,'inputs.c']]],
  ['num_5finputs_11',['NUM_INPUTS',['../group__input__handling.html#gga17ed9738c4fcd08b8a24a1d405fac706a5db28925d975294439624dfc133c4e0f',1,'inputs.h']]]
];
