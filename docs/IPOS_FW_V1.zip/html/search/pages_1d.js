var searchData=
[
  ['uart_20master_20task_0',['UART Master Task',['../stm32_usart_master_task.html',1,'stm32_overview']]],
  ['uart_20pd_20read_20timing_20sequence_1',['Figure 2 — PD-Write / UART / PD-Read Timing Sequence',['../communication_overview.html#autotoc_md15',1,'']]],
  ['usage_2',['Usage',['../stm32_usart_master_task.html#autotoc_md159',1,'7. Example Usage'],['../stm32_protocol.html#autotoc_md138',1,'7. Typical Usage'],['../log__flash_8c.html#autotoc_md59',1,'Typical Usage']]],
  ['usb_20command_20interface_3',['USB Command Interface',['../stm32_usb_commands.html',1,'stm32_overview']]],
  ['usb_20commands_4',['USB Commands',['../stm32_input_handler.html#autotoc_md109',1,'6. USB Commands'],['../stm32_flash_log.html#autotoc_md94',1,'7. USB Commands']]],
  ['usb_20print_20helper_5',['6. USB Print Helper',['../stm32_protocol.html#autotoc_md136',1,'']]],
  ['utility_20functions_6',['9. Utility Functions',['../stm32_app_main.html#autotoc_md78',1,'']]]
];
