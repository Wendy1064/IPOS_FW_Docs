var searchData=
[
  ['protocmd_0',['ProtoCmd',['../_i_p_o_s__071125_2_core_2_inc_2protocol_8h.html#ab913231010f74bb92fe8153deb654fd6',1,'ProtoCmd:&#160;protocol.h'],['../_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h.html#ab913231010f74bb92fe8153deb654fd6',1,'ProtoCmd:&#160;protocol.h']]],
  ['protorole_1',['ProtoRole',['../_i_p_o_s__071125_2_core_2_inc_2protocol_8h.html#abe23dea090170d3a1fc7c109f2c272b7',1,'ProtoRole:&#160;protocol.h'],['../_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h.html#abe23dea090170d3a1fc7c109f2c272b7',1,'ProtoRole:&#160;protocol.h']]]
];
