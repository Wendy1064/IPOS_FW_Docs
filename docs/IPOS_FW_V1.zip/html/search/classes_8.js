var searchData=
[
  ['varframe_0',['VarFrame',['../uart__master__task_8h.html#struct_var_frame',1,'']]]
];
