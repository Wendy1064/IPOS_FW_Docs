var searchData=
[
  ['6_20dependencies_0',['6. Dependencies',['../stm32_master_link.html#autotoc_md124',1,'']]],
  ['6_20example_20session_1',['6. Example Session',['../stm32_usb_commands.html#autotoc_md174',1,'']]],
  ['6_20freertos_20integration_2',['6. FreeRTOS Integration',['../stm32_flash_log.html#autotoc_md92',1,'']]],
  ['6_20plc_20communication_20logic_3',['6. PLC Communication Logic',['../stm32_app_main.html#autotoc_md75',1,'']]],
  ['6_20task_20initialization_4',['6. Task Initialization',['../stm32_usart_master_task.html#autotoc_md157',1,'']]],
  ['6_20timing_20and_20synchronization_5',['6. Timing and Synchronization',['../m40_iomap.html#autotoc_md195',1,'']]],
  ['6_20usb_20commands_6',['6. USB Commands',['../stm32_input_handler.html#autotoc_md109',1,'']]],
  ['6_20usb_20print_20helper_7',['6. USB Print Helper',['../stm32_protocol.html#autotoc_md136',1,'']]]
];
