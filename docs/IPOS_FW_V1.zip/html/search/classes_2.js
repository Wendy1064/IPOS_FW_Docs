var searchData=
[
  ['i2c_5finputstag_0',['I2C_InputsTag',['../abcc__hardware__abstraction_8c.html#struct_i2_c___inputs_tag',1,'']]],
  ['i2c_5foutputstag_1',['I2C_OutputsTag',['../abcc__hardware__abstraction_8c.html#struct_i2_c___outputs_tag',1,'']]],
  ['inputevent_5ft_2',['InputEvent_t',['../group__input__handling.html#struct_input_event__t',1,'']]]
];
