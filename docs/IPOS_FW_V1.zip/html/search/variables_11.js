var searchData=
[
  ['usbreadyflag_0',['usbReadyFlag',['../_i_p_o_s__071125_2_core_2_inc_2protocol_8h.html#a9ff0771c408ff05151526e5fc82eb860',1,'usbReadyFlag:&#160;protocol.h'],['../group__protocol.html#ga9ff0771c408ff05151526e5fc82eb860',1,'usbReadyFlag:&#160;protocol.c']]],
  ['usbtxbuf_1',['usbTxBuf',['../group__uart__master__task.html#gabac60e518d31943e808211083e11f886',1,'uart_master_task.c']]]
];
