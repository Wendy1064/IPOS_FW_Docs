var searchData=
[
  ['float32_0',['FLOAT32',['../abcc__types_8h.html#a6a3da5f1db8d485c0d2f5a7ba526c4a0',1,'abcc_types.h']]],
  ['float64_1',['FLOAT64',['../abcc__types_8h.html#aa8336782d864ba03efadb73a51260961',1,'abcc_types.h']]]
];
