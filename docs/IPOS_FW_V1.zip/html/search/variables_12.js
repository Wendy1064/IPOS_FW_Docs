var searchData=
[
  ['value_0',['value',['../_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h.html#a6e3775f6efa90ef06f8902bff3aad080',1,'ProtoFrame::value'],['../uart__master__task_8h.html#ac652175241bf952118facd0fc2c4ebb9',1,'VarFrame::value']]],
  ['var_5fid_1',['var_id',['../_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h.html#a653fb48b3f23d5a7c7350998af2bf20f',1,'ProtoFrame::var_id'],['../uart__master__task_8h.html#a9a968c2bdb78e02febb9db37c27b7b36',1,'VarFrame::var_id']]],
  ['verboselogging_2',['verboseLogging',['../group__app__main.html#ga13513b52ba27e18fced406e65011d1b9',1,'verboseLogging:&#160;app_main.c'],['../group__app__main.html#ga13513b52ba27e18fced406e65011d1b9',1,'verboseLogging:&#160;app_main.c'],['../group__app__main.html#ga13513b52ba27e18fced406e65011d1b9',1,'verboseLogging:&#160;app_main.c'],['../group__app__main.html#ga13513b52ba27e18fced406e65011d1b9',1,'verboseLogging:&#160;app_main.c'],['../group__protocol.html#ga13513b52ba27e18fced406e65011d1b9',1,'verboseLogging:&#160;app_main.c'],['../group__usb__commands.html#ga13513b52ba27e18fced406e65011d1b9',1,'verboseLogging:&#160;app_main.c']]]
];
