var searchData=
[
  ['3_20—_20pd_20cycle_20clock_20and_20synchronization_0',['Figure 3 — PD Cycle Clock and Synchronization',['../communication_overview.html#autotoc_md19',1,'']]],
  ['3_202_20data_20exchange_20timing_1',['3.2 Data Exchange Timing',['../communication_overview.html#autotoc_md13',1,'']]],
  ['3_203_20pd_20cycle_20synchronization_2',['3.3 PD Cycle Synchronization',['../communication_overview.html#autotoc_md17',1,'']]],
  ['3_204_20timing_20summary_3',['3.4 Timing Summary',['../communication_overview.html#autotoc_md21',1,'']]],
  ['3_20command_20summary_4',['3. Command Summary',['../stm32_usb_commands.html#autotoc_md170',1,'']]],
  ['3_20data_20flow_5',['3. Data Flow',['../stm32_input_handler.html#autotoc_md106',1,'']]],
  ['3_20flash_20layout_20and_20configuration_6',['3. Flash Layout and Configuration',['../stm32_flash_log.html#autotoc_md86',1,'']]],
  ['3_20generating_20the_20gsdml_20file_7',['3. Generating the GSDML File',['../m40_related.html#autotoc_md208',1,'']]],
  ['3_20input_20interrupts_8',['5.3 Input Interrupts',['../stm32_app_main.html#autotoc_md74',1,'']]],
  ['3_20key_20functions_9',['3. Key Functions',['../stm32_master_link.html#autotoc_md121',1,'']]],
  ['3_20message_20queues_10',['3. Message Queues',['../stm32_usart_master_task.html#autotoc_md152',1,'']]],
  ['3_20parser_20operation_11',['3. Parser Operation',['../stm32_protocol.html#autotoc_md133',1,'']]],
  ['3_20pd_20cycle_20synchronization_12',['3.3 PD Cycle Synchronization',['../communication_overview.html#autotoc_md17',1,'']]],
  ['3_20task_20creation_20summary_13',['3. Task Creation Summary',['../stm32_app_main.html#autotoc_md66',1,'']]]
];
