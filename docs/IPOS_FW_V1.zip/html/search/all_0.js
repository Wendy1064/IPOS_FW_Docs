var searchData=
[
  ['0x1_0',['PORTA (0x1)',['../m40_iomap.html#autotoc_md187',1,'']]],
  ['0x2_1',['PORTB (0x2)',['../m40_iomap.html#autotoc_md188',1,'']]],
  ['0x3_2',['PORTC (0x3)',['../m40_iomap.html#autotoc_md189',1,'']]],
  ['0x4_3',['STATUS_DEBUG (0x4)',['../m40_iomap.html#autotoc_md190',1,'']]],
  ['0x5_4',['STATUS_PLC (0x5)',['../m40_iomap.html#autotoc_md191',1,'']]],
  ['0x6_5',['STATUS_ACTIVE (0x6)',['../m40_iomap.html#autotoc_md193',1,'']]],
  ['0x7_6',['STATUS_DEBUG_TRU (0x7)',['../m40_iomap.html#autotoc_md194',1,'']]]
];
