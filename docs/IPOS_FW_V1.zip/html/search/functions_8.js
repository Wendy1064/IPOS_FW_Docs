var searchData=
[
  ['initialise_5fmonitor_5fhandles_0',['initialise_monitor_handles',['../_i_p_o_s__071125_2_core_2_src_2syscalls_8c.html#a25c7f100d498300fff65568c2fcfe639',1,'initialise_monitor_handles():&#160;syscalls.c'],['../_i_p_o_s___m40___v1__00__101125_2_core_2_src_2syscalls_8c.html#a25c7f100d498300fff65568c2fcfe639',1,'initialise_monitor_handles():&#160;syscalls.c']]],
  ['input_5fgetstate_1',['Input_GetState',['../group__input__handling.html#ga821c60e4615c59b5cb7d3eb7f040a6c6',1,'Input_GetState(InputName input):&#160;inputs.c'],['../group__input__handling.html#ga821c60e4615c59b5cb7d3eb7f040a6c6',1,'Input_GetState(InputName input):&#160;inputs.c']]],
  ['inputstatetostring_2',['InputStateToString',['../group__input__handling.html#ga2eb52e5e7cb7d0503368203e55a47b8d',1,'InputStateToString(InputName input, uint8_t state):&#160;inputs.c'],['../group__input__handling.html#ga2eb52e5e7cb7d0503368203e55a47b8d',1,'InputStateToString(InputName input, uint8_t value):&#160;inputs.c']]]
];
