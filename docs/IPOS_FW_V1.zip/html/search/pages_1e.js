var searchData=
[
  ['workflow_0',['Typical Workflow',['../safety__utils_8c.html#autotoc_md57',1,'']]],
  ['write_20uart_20pd_20read_20timing_20sequence_1',['Figure 2 — PD-Write / UART / PD-Read Timing Sequence',['../communication_overview.html#autotoc_md15',1,'']]]
];
