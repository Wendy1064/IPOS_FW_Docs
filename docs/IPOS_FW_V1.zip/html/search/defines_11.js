var searchData=
[
  ['w25q_5fcs_5fpin_0',['W25Q_CS_Pin',['../w25q_8h.html#adbe676a4c841cfbef06cfa945fcb6e52',1,'w25q.h']]],
  ['w25q_5fcs_5fport_1',['W25Q_CS_Port',['../w25q_8h.html#a9cdb249cddd466b909aabaa652b3eb51',1,'w25q.h']]]
];
