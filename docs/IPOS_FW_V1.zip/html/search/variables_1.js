var searchData=
[
  ['bjp11_0',['bJP11',['../abcc__hardware__abstraction_8c.html#ad484d7503124e9ae4589b9f7e907e71f',1,'I2C_InputsTag::bJP11'],['../abcc__hardware__abstraction_8c.html#a019bc63df05d61770f4786ab4da07068',1,'I2C_OutputsTag::bJP11']]],
  ['bleds_1',['bLEDs',['../abcc__hardware__abstraction_8c.html#a8f56184607eae0f455f41cfe7606e8a2',1,'I2C_OutputsTag']]],
  ['bmd_2',['bMD',['../abcc__hardware__abstraction_8c.html#a930084962219c7f5cffa9867504fda6e',1,'I2C_InputsTag']]],
  ['bmi_3',['bMI',['../abcc__hardware__abstraction_8c.html#acdfa731b45326daff459a2896455a343',1,'I2C_InputsTag']]],
  ['bootevent_4',['BootEvent',['../group__app__main.html#gad161edf016c8165e59d5fa88aeb008aa',1,'app_main.c']]],
  ['bs2_5',['bS2',['../abcc__hardware__abstraction_8c.html#a2517943d585ed6b7af769f031342bc40',1,'I2C_InputsTag']]],
  ['bs3_6',['bS3',['../abcc__hardware__abstraction_8c.html#ad69aeaf9b8d8f7092e14b52c6f7b9c3e',1,'I2C_InputsTag']]],
  ['bs4_7',['bS4',['../abcc__hardware__abstraction_8c.html#a154e66f9010eded8c8c0b0ff8770b068',1,'I2C_InputsTag']]],
  ['bs5_8',['bS5',['../abcc__hardware__abstraction_8c.html#a460e599b30adc3b1626dab365c3d35cd',1,'I2C_InputsTag']]],
  ['buf_9',['buf',['../_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h.html#a2ac6045807515487871a1690304e7acd',1,'ProtoParser::buf'],['../ringbuffer_8h.html#a82b8cf939e38c32e37fa8a54d4df33ac',1,'RingBuffer::buf']]],
  ['build_5fdate_10',['build_date',['../group__app__main.html#gaa34fa035dd3b887a67e9b0e34852f0eb',1,'app_main.c']]],
  ['build_5ftime_11',['build_time',['../group__app__main.html#ga766eb4a0acd5a2b6c58dac458bd7da9b',1,'app_main.c']]]
];
