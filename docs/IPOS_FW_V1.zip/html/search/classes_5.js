var searchData=
[
  ['protoframe_0',['ProtoFrame',['../_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h.html#struct_proto_frame',1,'']]],
  ['protoparser_1',['ProtoParser',['../_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h.html#struct_proto_parser',1,'']]]
];
