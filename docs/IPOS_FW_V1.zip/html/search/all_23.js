var searchData=
[
  ['—_20communication_20topology_0',['Figure 1 — Communication Topology',['../communication_overview.html#autotoc_md11',1,'']]],
  ['—_20input_20c_1',['Input Handler — input.c',['../stm32_input_handler.html#autotoc_md101',1,'']]],
  ['—_20pd_20cycle_20clock_20and_20synchronization_2',['Figure 3 — PD Cycle Clock and Synchronization',['../communication_overview.html#autotoc_md19',1,'']]],
  ['—_20pd_20write_20uart_20pd_20read_20timing_20sequence_3',['Figure 2 — PD-Write / UART / PD-Read Timing Sequence',['../communication_overview.html#autotoc_md15',1,'']]]
];
