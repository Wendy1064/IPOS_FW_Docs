var searchData=
[
  ['newspi2received_0',['newSPI2received',['../abcc__hardware__abstraction_8c.html#a935cf6a78beb7df83d477c66dae92e54',1,'abcc_hardware_abstraction.c']]],
  ['newstate_1',['newState',['../group__input__handling.html#ae7ef175f83ec7db0d2059b4816010eea',1,'InputEvent_t']]]
];
