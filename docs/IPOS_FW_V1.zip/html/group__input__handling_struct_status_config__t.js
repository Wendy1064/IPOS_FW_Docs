var group__input__handling_struct_status_config__t =
[
    [ "enabled", "group__input__handling.html#a98ed2506ebb1973330c1c7cfff799de5", null ],
    [ "intervalMs", "group__input__handling.html#a54b6e17c6f95d18d342f049edbc861a8", null ]
];