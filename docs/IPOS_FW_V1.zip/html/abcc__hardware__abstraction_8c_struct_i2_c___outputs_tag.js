var abcc__hardware__abstraction_8c_struct_i2_c___outputs_tag =
[
    [ "bJP11", "abcc__hardware__abstraction_8c.html#a019bc63df05d61770f4786ab4da07068", null ],
    [ "bLEDs", "abcc__hardware__abstraction_8c.html#a8f56184607eae0f455f41cfe7606e8a2", null ]
];