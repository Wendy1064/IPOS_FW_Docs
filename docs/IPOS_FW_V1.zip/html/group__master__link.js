var group__master__link =
[
    [ "RB_SIZE", "group__master__link.html#ga4ab5f7800f96dec4076a4a0c8aa634b7", null ],
    [ "UART_RX_DMA_CHUNK", "group__master__link.html#gac7b5ea119b0669eaed97efae6ebd4c2f", null ],
    [ "__attribute__", "group__master__link.html#gaf9aace1b44b73111e15aa39f06f43456", null ],
    [ "HAL_UART_ErrorCallback", "group__master__link.html#ga0e0456ea96d55db31de947fb3e954f18", null ],
    [ "HAL_UARTEx_RxEventCallback", "group__master__link.html#ga925534fb8bf7ca464fd05c982fe4bfa0", null ],
    [ "master_link_attach_task_handle", "group__master__link.html#gaf426d71cc3d545680207a5c14fc915e0", null ],
    [ "master_link_init", "group__master__link.html#ga67e95828277c0771ad0a573322a5191d", null ],
    [ "master_link_poll", "group__master__link.html#gaa0c4ce7bf2ecce9ca76ebf74d34a9812", null ],
    [ "master_link_start", "group__master__link.html#ga136d58a2733b7acdf639c5bf42685536", null ],
    [ "master_read_u16", "group__master__link.html#gab4078648ce04415c64875e869c39d12c", null ],
    [ "master_write_u16", "group__master__link.html#gaac6847f1075654acb90ca1225ef9d132", null ]
];