var ports__hw_8c =
[
    [ "Job_Sel_In_Read", "ports__hw_8c.html#ac88893c1d3af07ee3d7a475d2e897900", null ],
    [ "Job_Sel_Out_Write", "ports__hw_8c.html#a26b7eae3aff2afa4fbebf4e0fb1d746e", null ],
    [ "PortA_Read", "ports__hw_8c.html#a4c9ee32e5c488c4c3cb7e4ef8051b266", null ],
    [ "PortB_Write", "ports__hw_8c.html#aa00a65226ccf665bd514b15cb085cff4", null ],
    [ "jobSelShadow", "ports__hw_8c.html#a11e157ef9a3c2f2854ed16b082712421", null ],
    [ "PortBShadow", "ports__hw_8c.html#a6dc92a35a836ceef8917b46ffba62367", null ],
    [ "Tru_inShadow", "ports__hw_8c.html#a42404a353f7e430ba0a9f4def5eea003", null ]
];