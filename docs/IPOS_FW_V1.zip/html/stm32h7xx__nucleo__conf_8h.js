var stm32h7xx__nucleo__conf_8h =
[
    [ "BSP_BUTTON_USER_IT_PRIORITY", "group___s_t_m32_c0_x_x___n_u_c_l_e_o___c_o_n_f_i_g___exported___constants.html#ga08276683c87b1e200ca1e457937cbb12", null ],
    [ "USE_BSP_COM_FEATURE", "group___s_t_m32_c0_x_x___n_u_c_l_e_o___c_o_n_f_i_g___exported___constants.html#gaf31d1fe932254b4a28dea42a59213a70", null ],
    [ "USE_COM_LOG", "group___s_t_m32_c0_x_x___n_u_c_l_e_o___c_o_n_f_i_g___exported___constants.html#gae4e30044c77234f9c00f69ece2b417df", null ],
    [ "USE_NUCLEO_144", "group___s_t_m32_c0_x_x___n_u_c_l_e_o___c_o_n_f_i_g___exported___constants.html#ga35c2bbf668d3eee30834e377e4087d65", null ],
    [ "USE_NUCLEO_H753ZI", "group___s_t_m32_c0_x_x___n_u_c_l_e_o___c_o_n_f_i_g___exported___constants.html#ga5e91e4751ecf56914cdb2b7a3e3f3a31", null ],
    [ "USE_STM32H7XX_NUCLEO", "group___s_t_m32_c0_x_x___n_u_c_l_e_o___c_o_n_f_i_g___exported___constants.html#gace0100d8c58ed9f0608bb2942d1ba311", null ]
];