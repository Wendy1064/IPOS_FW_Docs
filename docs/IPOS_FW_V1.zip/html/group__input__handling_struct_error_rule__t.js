var group__input__handling_struct_error_rule__t =
[
    [ "active", "group__input__handling.html#a44df3b91ab32ebdd1d05683fa21014f2", null ],
    [ "condition", "group__input__handling.html#a515f4859b836a577b00f57e41031722e", null ],
    [ "msgActive", "group__input__handling.html#a3c78ceddd33423e295a52862c71a0f99", null ],
    [ "msgCleared", "group__input__handling.html#aeaaac4fe64aa26ec2a281ef1f619219f", null ]
];