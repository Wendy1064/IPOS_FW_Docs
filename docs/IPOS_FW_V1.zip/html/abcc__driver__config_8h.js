var abcc__driver__config_8h =
[
    [ "ABCC_API_COMMAND_RESPONSE_LIST", "abcc__driver__config_8h.html#a552603f5c134746813983df0ceb0e52d", null ],
    [ "ABCC_CFG_DRV_ASSUME_FW_UPDATE_ENABLED", "abcc__driver__config_8h.html#a649effc862fccfd6111ad77d08e06639", null ],
    [ "ABCC_CFG_DRV_SERIAL_ENABLED", "abcc__driver__config_8h.html#ab99bc4af04a79e6b11ba262229585a3d", null ],
    [ "ABCC_CFG_DRV_SPI_ENABLED", "abcc__driver__config_8h.html#a2db7b17df6370119b8e9fa064ba1518f", null ],
    [ "ABCC_CFG_INT_ENABLED", "abcc__driver__config_8h.html#a70221a7878551f8241fc8ed940bb3cc9", null ],
    [ "ABCC_CFG_LOG_COLORS_ENABLED", "abcc__driver__config_8h.html#ad3e75b334a4385d275acb6392e959d37", null ],
    [ "ABCC_CFG_LOG_FILE_LINE_ENABLED", "abcc__driver__config_8h.html#a6c1bce69be94f1c37750ef09640026b0", null ],
    [ "ABCC_CFG_LOG_SEVERITY", "abcc__driver__config_8h.html#a0565ba1531582773de4af9d020894594", null ],
    [ "ABCC_CFG_LOG_STRINGS_ENABLED", "abcc__driver__config_8h.html#ae70de254baee3f144d816fadae0e21e5", null ],
    [ "ABCC_CFG_LOG_TIMESTAMPS_ENABLED", "abcc__driver__config_8h.html#aa7b6aa1740ac3d114689e2c0c15f79a9", null ],
    [ "ABCC_CFG_MAX_PROCESS_DATA_SIZE", "abcc__driver__config_8h.html#a60967bb267faa19c9994095699afe9f9", null ],
    [ "ABCC_CFG_MESSAGE_SIZE_CHECK_ENABLED", "abcc__driver__config_8h.html#a9303da03bd66d440045cba465ae3b1a9", null ],
    [ "ABCC_CFG_MODULE_ID_PINS_CONN", "abcc__driver__config_8h.html#a19c81d4dde0a4567ce2835d912abc591", null ],
    [ "ABCC_CFG_OP_MODE_GETTABLE", "abcc__driver__config_8h.html#a80167195c0414f799343718344c41976", null ],
    [ "ABCC_CFG_OP_MODE_SETTABLE", "abcc__driver__config_8h.html#ae97996b6b7aac3f2bff2238ddd169021", null ],
    [ "ABCC_CFG_POLL_ABCC_IRQ_PIN_ENABLED", "abcc__driver__config_8h.html#a12b08818bad91985a81a505c1036c589", null ],
    [ "ABCC_CFG_REMAP_SUPPORT_ENABLED", "abcc__driver__config_8h.html#a2483dbe56fb5767b290e93116e960e8a", null ],
    [ "ANB_FSI_OBJ_ENABLE", "abcc__driver__config_8h.html#a7231a05a4b244308f1b98911182d9332", null ],
    [ "EIP_OBJ_ENABLE", "abcc__driver__config_8h.html#aec5efc8246c8387f8667e7f3ce9cfaa6", null ],
    [ "MOD_OBJ_ENABLE", "abcc__driver__config_8h.html#a708703ed28c23fbc59696e474503d75f", null ],
    [ "PRT_OBJ_ENABLE", "abcc__driver__config_8h.html#a0ab30ce7f88f8ecc4477a4a9623d4e17", null ]
];