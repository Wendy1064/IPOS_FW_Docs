var ring__buffer_8h =
[
    [ "RingBuffer", "ringbuffer_8h.html#struct_ring_buffer", [
      [ "buf", "ringbuffer_8h.html#a82b8cf939e38c32e37fa8a54d4df33ac", null ],
      [ "head", "ringbuffer_8h.html#a87817113715c194a3cfe19678fcfa0b4", null ],
      [ "size", "ringbuffer_8h.html#a4d7b67ecc3d498a5093dea1562daa75c", null ],
      [ "tail", "ringbuffer_8h.html#a2e915532ebf337299d19621f0a90bc16", null ]
    ] ]
];