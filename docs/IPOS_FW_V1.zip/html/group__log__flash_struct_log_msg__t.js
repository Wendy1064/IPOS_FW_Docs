var group__log__flash_struct_log_msg__t =
[
    [ "code", "group__log__flash.html#a4179f2d03ffd9ba1251cc59264445024", null ],
    [ "flags", "group__log__flash.html#a6d61b9113b3afce68a79f39064b728a3", null ],
    [ "ms", "group__log__flash.html#aac4d7026d10f335a7d29596699b16352", null ],
    [ "msg", "group__log__flash.html#a7c8640c42e67e8ffc55776fd1847fba3", null ],
    [ "seq", "group__log__flash.html#a87117ebd77c8c63c16e9a25de7180e52", null ]
];