var dir_ddd7ef01ca278b584177422192135beb =
[
    [ "bdma.h", "bdma_8h.html", "bdma_8h" ],
    [ "command_parser.h", "command__parser_8h.html", "command__parser_8h" ],
    [ "debug.h", "debug_8h.html", "debug_8h" ],
    [ "dma.h", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2dma_8h.html", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2dma_8h" ],
    [ "gpio.h", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2gpio_8h.html", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2gpio_8h" ],
    [ "i2c.h", "i2c_8h.html", "i2c_8h" ],
    [ "main.h", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2main_8h.html", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2main_8h" ],
    [ "protocol.h", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h.html", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h" ],
    [ "ringbuffer.h", "ringbuffer_8h.html", "ringbuffer_8h" ],
    [ "slave_link.h", "slave__link_8h.html", "slave__link_8h" ],
    [ "spi.h", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2spi_8h.html", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2spi_8h" ],
    [ "stm32h7xx_hal_conf.h", "stm32h7xx__hal__conf_8h.html", "stm32h7xx__hal__conf_8h" ],
    [ "stm32h7xx_it.h", "stm32h7xx__it_8h.html", "stm32h7xx__it_8h" ],
    [ "stm32h7xx_nucleo_conf.h", "stm32h7xx__nucleo__conf_8h.html", "stm32h7xx__nucleo__conf_8h" ],
    [ "usart.h", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2usart_8h.html", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2usart_8h" ],
    [ "usb_otg.h", "usb__otg_8h.html", "usb__otg_8h" ]
];