var ports__hw_8h_struct_gpio_map__t =
[
    [ "pin", "ports__hw_8h.html#a498e98bea6399b3840b5f267b7e987c1", null ],
    [ "port", "ports__hw_8h.html#a5bf1902cd991dc69e8d15536697d4710", null ]
];