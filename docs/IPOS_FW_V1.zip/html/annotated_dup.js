var annotated_dup =
[
    [ "ErrorConditionFn", "group__input__handling.html#struct_error_condition_fn", null ],
    [ "ErrorRule_t", "group__input__handling.html#struct_error_rule__t", "group__input__handling_struct_error_rule__t" ],
    [ "GpioMap_t", "ports__hw_8h.html#struct_gpio_map__t", "ports__hw_8h_struct_gpio_map__t" ],
    [ "I2C_InputsTag", "abcc__hardware__abstraction_8c.html#struct_i2_c___inputs_tag", "abcc__hardware__abstraction_8c_struct_i2_c___inputs_tag" ],
    [ "I2C_OutputsTag", "abcc__hardware__abstraction_8c.html#struct_i2_c___outputs_tag", "abcc__hardware__abstraction_8c_struct_i2_c___outputs_tag" ],
    [ "InputEvent_t", "group__input__handling.html#struct_input_event__t", "group__input__handling_struct_input_event__t" ],
    [ "LogMsg_t", "group__log__flash.html#struct_log_msg__t", "group__log__flash_struct_log_msg__t" ],
    [ "MAX31855_Data", "max31855_8h.html#struct_m_a_x31855___data", "max31855_8h_struct_m_a_x31855___data" ],
    [ "ProtoFrame", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h.html#struct_proto_frame", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h_struct_proto_frame" ],
    [ "ProtoParser", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h.html#struct_proto_parser", "_i_p_o_s___m40___v1__00__101125_2_core_2_inc_2protocol_8h_struct_proto_parser" ],
    [ "RingBuffer", "ringbuffer_8h.html#struct_ring_buffer", "ringbuffer_8h_struct_ring_buffer" ],
    [ "StatusConfig_t", "group__input__handling.html#struct_status_config__t", "group__input__handling_struct_status_config__t" ],
    [ "VarFrame", "uart__master__task_8h.html#struct_var_frame", "uart__master__task_8h_struct_var_frame" ]
];