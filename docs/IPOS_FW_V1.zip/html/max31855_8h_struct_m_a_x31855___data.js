var max31855_8h_struct_m_a_x31855___data =
[
    [ "cj_c", "max31855_8h.html#a2674f2d6def3ce4220455e98dcec5134", null ],
    [ "fault", "max31855_8h.html#a6a8251f4410c4619df58357e6dcf19bd", null ],
    [ "flag", "max31855_8h.html#aed4826cfab9116a5afda48070753fa90", null ],
    [ "rangeFault", "max31855_8h.html#a9ad6e5bb1cd8ecc18e6ac97d7519a7bc", null ],
    [ "raw", "max31855_8h.html#a57c8c3ae38c1a9b96124632257bb0798", null ],
    [ "tc_c", "max31855_8h.html#ada9890bb7faf30dfa02069d109c5c182", null ]
];