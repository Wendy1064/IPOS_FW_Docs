var dir_0a45d8120d57e90af8f148085a17d88d =
[
    [ "Core", "dir_4f4e774cf7dd7c1a8739422ddb9dd459.html", "dir_4f4e774cf7dd7c1a8739422ddb9dd459" ],
    [ "Docs", "dir_3db49c8f20c6bbd85482d9b9de7634ea.html", null ],
    [ "src", "dir_1a97126beaff9f626f61ee8948c3b63b.html", "dir_1a97126beaff9f626f61ee8948c3b63b" ]
];