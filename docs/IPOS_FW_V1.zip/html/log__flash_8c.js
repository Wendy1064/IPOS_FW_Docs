var log__flash_8c =
[
    [ "Log_Append", "group__log__flash.html#gaf7be7be3d5aa3ad8ce8eb8f080d34baa", null ],
    [ "Log_CountValid", "group__log__flash.html#ga68cbde1bd242d16f0c97aa1a6a982674", null ],
    [ "Log_GetSequenceNext", "group__log__flash.html#ga2d734e69f4ea869029a8bb750d24540d", null ],
    [ "Log_GetWriteIndex", "group__log__flash.html#gab44417e89973f9f0c7b2d0aaa7ba25ac", null ],
    [ "Log_Init", "group__log__flash.html#ga5f3b99e0966ad05cc569bea9b503b148", null ],
    [ "Log_ReadLastN", "group__log__flash.html#ga661cd6aecf9a843941229e9789ef8d8f", null ],
    [ "vTaskLogWriter", "group__log__flash.html#gae4a37f521a0098079c9f62bb1014569f", null ],
    [ "logQueue", "group__log__flash.html#gaa42f4a4e54ef104c44df1ce00a619e7a", null ],
    [ "seq_next", "group__log__flash.html#ga960039267784d0b901fd31737f74220d", null ],
    [ "wr_index", "group__log__flash.html#ga2e3467bd12b4bc5a03d2ef75df455976", null ]
];