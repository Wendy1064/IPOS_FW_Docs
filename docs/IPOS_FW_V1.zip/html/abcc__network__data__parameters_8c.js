var abcc__network__data__parameters_8c =
[
    [ "ABCC_API_CbfCyclicalProcessing", "abcc__network__data__parameters_8c.html#a760fef398da0f6a0f30dde40216d7045", null ],
    [ "ABCC_API_CbfGetNumAdi", "abcc__network__data__parameters_8c.html#a247246037dc1f2bd15f2e471f37fdd87", null ],
    [ "ABCC_API_asAdiEntryList", "abcc__network__data__parameters_8c.html#a04adc38175d9e971bba2a48d0703bac8", null ],
    [ "ABCC_API_asAdObjDefaultMap", "abcc__network__data__parameters_8c.html#a660ebb72c1d03625e6eeed2d3907a860", null ],
    [ "appl_iPortA", "abcc__network__data__parameters_8c.html#ac4dcd8ce6bc7775cd1e8e380e044193c", null ],
    [ "appl_iPortB", "abcc__network__data__parameters_8c.html#a91c7fbfdfa53b717491c1136a0826397", null ],
    [ "appl_iPortC", "abcc__network__data__parameters_8c.html#a198510bead909eb05cb90eef960d433f", null ],
    [ "appl_iStatusActive", "abcc__network__data__parameters_8c.html#ae6c91dfc98877d0ef7eac0c1104b56ab", null ],
    [ "appl_iStatusDebug", "abcc__network__data__parameters_8c.html#a8f048df8801716ee7d55455e5e43f625", null ],
    [ "appl_iStatusDebugTru", "abcc__network__data__parameters_8c.html#ac72a664dc1998c35d04d8815e5b38d1f", null ],
    [ "appl_iStatusPLC", "abcc__network__data__parameters_8c.html#a7ac4640ff340fb490ba79029ce9f88b4", null ],
    [ "pd_StatusActive", "abcc__network__data__parameters_8c.html#a03a516afe7848a993910f2410808194e", null ],
    [ "pd_StatusDebug", "abcc__network__data__parameters_8c.html#ab371682a07f576ec4e8a0d8378ea4949", null ],
    [ "pd_StatusPLC", "abcc__network__data__parameters_8c.html#a6c72761cd9b1fca76b98d04a85dec2ec", null ],
    [ "PortA_val", "abcc__network__data__parameters_8c.html#ae12bde2d42d3c538422750ddd61e925a", null ],
    [ "PortB_val", "abcc__network__data__parameters_8c.html#aad6f6e948bb37d430c5d8c32fd26efe0", null ],
    [ "PortC_val", "abcc__network__data__parameters_8c.html#a604457104f2e200ac939b40348412f0b", null ],
    [ "StatusActive_val", "abcc__network__data__parameters_8c.html#a7efd8189f7a3fa73faaa42229a0ae873", null ],
    [ "StatusDebug_val", "abcc__network__data__parameters_8c.html#ad10f9af84e35553eeb832027c6f84daa", null ],
    [ "StatusDebugTru_val", "abcc__network__data__parameters_8c.html#a44b2f81c884ac2512c9729097d6013b2", null ],
    [ "StatusPLC_val", "abcc__network__data__parameters_8c.html#a661bd3a51f758a2c12f6c4c1fa4d9232", null ]
];