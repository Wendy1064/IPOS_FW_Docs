var dir_377647f1b87e2ef37ad9b1bfbc53f789 =
[
    [ "Core", "dir_3489c8b872154c0d5a7e42c9931c0282.html", "dir_3489c8b872154c0d5a7e42c9931c0282" ],
    [ "Docs", "dir_53b5e890bd47040f878e0cbb9d2b25ef.html", null ]
];