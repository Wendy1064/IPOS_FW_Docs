var group__protocol =
[
    [ "MAX_USB_BUFF", "group__protocol.html#gacb2252c58bff24bc9fcd5848ac9b1d9d", null ],
    [ "proto_build_ack", "group__protocol.html#ga05e2d2d6edbf121ecf479ddbaf47e03d", null ],
    [ "proto_build_read", "group__protocol.html#ga4cc33e9868129062ecf64b316b43dcf6", null ],
    [ "proto_build_readr", "group__protocol.html#ga02c6e9492c7b3578ce7b3e9212cea6f7", null ],
    [ "proto_build_write", "group__protocol.html#ga95064f228b494d27449fa09019d639c8", null ],
    [ "proto_init", "group__protocol.html#ga8970bcd0e0af17f42b3b3a6d83f3d195", null ],
    [ "proto_push", "group__protocol.html#gadbb6342eec2b0de6e1c7ab042f1448e1", null ],
    [ "proto_reset", "group__protocol.html#gacad3e241e27ce9c8dc1ca4535f41f9a5", null ],
    [ "UsbPrintf", "group__protocol.html#gaf2833787d9240d7acbb8e759d6cf775a", null ],
    [ "hUsbDeviceFS", "group__protocol.html#gafe8a2d9e10b33d5e7906f9f04f95358e", null ],
    [ "usbReadyFlag", "group__protocol.html#ga9ff0771c408ff05151526e5fc82eb860", null ],
    [ "verboseLogging", "group__protocol.html#ga13513b52ba27e18fced406e65011d1b9", null ]
];