var slave__link_8c =
[
    [ "RB_SIZE", "slave__link_8c.html#a4ab5f7800f96dec4076a4a0c8aa634b7", null ],
    [ "UART_RX_DMA_CHUNK", "slave__link_8c.html#ac7b5ea119b0669eaed97efae6ebd4c2f", null ],
    [ "__attribute__", "slave__link_8c.html#ac90702344605248dcf5e72b78141b2c1", null ],
    [ "HAL_UART_ErrorCallback", "slave__link_8c.html#a0e0456ea96d55db31de947fb3e954f18", null ],
    [ "HAL_UARTEx_RxEventCallback", "slave__link_8c.html#a925534fb8bf7ca464fd05c982fe4bfa0", null ],
    [ "slave_get_reg", "slave__link_8c.html#a8bdf6f063c53b3e45d36a8cd9db43608", null ],
    [ "slave_link_poll", "slave__link_8c.html#a58ba81efee4570ef875945bb78f7391e", null ],
    [ "slave_link_start", "slave__link_8c.html#adebdc3501c69902cbee16fc4424619b5", null ],
    [ "slave_set_reg", "slave__link_8c.html#a8c8839cf5d8cb692c3b99b83af51556a", null ],
    [ "huart2", "slave__link_8c.html#aa9479c261d65eecedd3d9582f7f0f89c", null ]
];