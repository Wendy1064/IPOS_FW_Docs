var debug_8h =
[
    [ "DEBUG_Init", "debug_8h.html#a84f2b097553af1cf3c42dfd0e453bdc0", null ],
    [ "DEBUG_Printf", "debug_8h.html#a2ac304259ea40252c0b7a86ee236db2a", null ]
];