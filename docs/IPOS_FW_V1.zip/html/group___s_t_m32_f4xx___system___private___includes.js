var group___s_t_m32_f4xx___system___private___includes =
[
    [ "HSE_VALUE", "group___s_t_m32_f4xx___system___private___includes.html#gaeafcff4f57440c60e64812dddd13e7cb", null ],
    [ "HSI_VALUE", "group___s_t_m32_f4xx___system___private___includes.html#gaaa8c76e274d0f6dd2cefb5d0b17fbc37", null ]
];